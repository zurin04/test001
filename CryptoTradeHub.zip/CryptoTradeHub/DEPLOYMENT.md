# CryptoTrade Academy - VPS Deployment Guide

This guide provides comprehensive instructions for deploying the CryptoTrade Academy platform on a VPS.

## Prerequisites

- Ubuntu 20.04+ or similar Linux distribution
- Minimum 1GB RAM (2GB recommended)
- Minimum 5GB disk space (10GB recommended)
- Root access to the server
- Domain name (optional but recommended)

## Quick Deployment

### 1. Download and Run Deployment Script

```bash
# Download the deployment script
wget https://raw.githubusercontent.com/your-repo/cryptotrade-academy/main/deploy.sh

# Make it executable
chmod +x deploy.sh

# Run the deployment
sudo ./deploy.sh
```

### 2. Configure Environment Variables

Edit the environment file:

```bash
sudo nano /opt/cryptotrade-academy/.env
```

Update the following required variables:

```env
# Database password
POSTGRES_PASSWORD=your_very_secure_database_password

# Session secret (generate a random string)
SESSION_SECRET=your_super_long_random_session_secret_here

# Stripe keys (for payments)
STRIPE_SECRET_KEY=sk_live_your_stripe_secret_key
VITE_STRIPE_PUBLIC_KEY=pk_live_your_stripe_public_key

# Your domain
REPLIT_DOMAINS=yourdomain.com,www.yourdomain.com
```

### 3. Start the Application

```bash
sudo systemctl start cryptotrade-academy
sudo systemctl status cryptotrade-academy
```

## Manual Deployment

### 1. System Setup

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh
sudo usermod -aG docker $USER

# Install Docker Compose
sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose
```

### 2. Application Setup

```bash
# Create application directory
sudo mkdir -p /opt/cryptotrade-academy
cd /opt/cryptotrade-academy

# Copy your application files
# (Upload via SCP, git clone, etc.)

# Copy environment file
cp .env.production .env

# Edit environment variables
sudo nano .env
```

### 3. Deploy with Docker Compose

```bash
# Build and start services
sudo docker-compose up -d --build

# Check status
sudo docker-compose ps

# View logs
sudo docker-compose logs -f
```

## SSL Certificate Setup

### Option 1: Let's Encrypt (Recommended for production)

```bash
# Install Certbot
sudo apt install certbot

# Stop nginx temporarily
sudo docker-compose stop nginx

# Generate certificate
sudo certbot certonly --standalone -d yourdomain.com -d www.yourdomain.com

# Copy certificates
sudo cp /etc/letsencrypt/live/yourdomain.com/fullchain.pem /etc/nginx/ssl/cert.pem
sudo cp /etc/letsencrypt/live/yourdomain.com/privkey.pem /etc/nginx/ssl/key.pem

# Restart nginx
sudo docker-compose start nginx
```

### Option 2: Self-signed (Development/Testing)

The deployment script automatically generates self-signed certificates for testing.

## Monitoring and Maintenance

### Check Application Status

```bash
# Check all services
sudo docker-compose ps

# Check specific service logs
sudo docker-compose logs app
sudo docker-compose logs postgres
sudo docker-compose logs nginx

# Check system resources
htop
df -h
```

### Backup and Restore

```bash
# Manual backup
sudo /usr/local/bin/backup-app.sh

# List backups
ls -la /opt/backups/

# Restore database from backup
sudo docker exec -i cryptotrade-db psql -U postgres cryptotrade_academy < /opt/backups/database_YYYYMMDD_HHMMSS.sql
```

### Update Application

```bash
cd /opt/cryptotrade-academy

# Pull latest code
git pull

# Rebuild and restart
sudo docker-compose down
sudo docker-compose up -d --build
```

## Troubleshooting

### Common Issues

1. **Port Already in Use**
   ```bash
   sudo netstat -tlnp | grep :80
   sudo systemctl stop apache2  # if Apache is running
   ```

2. **Database Connection Issues**
   ```bash
   # Check database logs
   sudo docker-compose logs postgres
   
   # Connect to database manually
   sudo docker exec -it cryptotrade-db psql -U postgres cryptotrade_academy
   ```

3. **SSL Certificate Issues**
   ```bash
   # Check certificate validity
   openssl x509 -in /etc/nginx/ssl/cert.pem -text -noout
   
   # Check nginx configuration
   sudo docker exec cryptotrade-nginx nginx -t
   ```

4. **Memory Issues**
   ```bash
   # Check memory usage
   free -h
   
   # Restart services if needed
   sudo docker-compose restart
   ```

### Log Locations

- Application logs: `sudo docker-compose logs app`
- Nginx logs: `sudo docker-compose logs nginx`
- Database logs: `sudo docker-compose logs postgres`
- System logs: `/var/log/syslog`
- Monitoring logs: `/var/log/monitor-app.log`

## Security Considerations

1. **Firewall Configuration**
   - Only ports 22 (SSH), 80 (HTTP), and 443 (HTTPS) are open
   - SSH access should use key-based authentication
   - Consider changing the default SSH port

2. **Regular Updates**
   ```bash
   # Update system packages
   sudo apt update && sudo apt upgrade
   
   # Update Docker images
   sudo docker-compose pull
   sudo docker-compose up -d
   ```

3. **Monitoring**
   - Set up log monitoring and alerting
   - Monitor disk space and memory usage
   - Regular security audits

## Performance Optimization

### For High Traffic

1. **Database Optimization**
   ```bash
   # Increase shared_buffers in postgres
   # Add to docker-compose.yml under postgres service:
   command: postgres -c shared_buffers=256MB -c max_connections=200
   ```

2. **Redis Caching**
   ```bash
   # Redis is included in docker-compose.yml
   # Configure session storage to use Redis
   ```

3. **CDN Setup**
   - Use a CDN for static assets
   - Configure nginx to serve static files directly

## Support

For issues and support:
1. Check the logs first
2. Review this documentation
3. Check the GitHub issues
4. Contact support with log excerpts and error details

## Production Checklist

- [ ] Environment variables configured
- [ ] SSL certificate installed
- [ ] Database password changed
- [ ] Session secret generated
- [ ] Stripe keys configured (if using payments)
- [ ] Domain DNS configured
- [ ] Firewall enabled
- [ ] Backups scheduled
- [ ] Monitoring enabled
- [ ] SSL certificate auto-renewal setup