# CryptoTrade Academy

A comprehensive cryptocurrency trading education platform with crypto payment integration and admin management.

## Features

- 🎓 **Three-tier Learning System**: Basic (Free), Intermediate ($50), Advanced ($100)
- 💰 **Dual Payment Methods**: Traditional card payments via Stripe + Cryptocurrency payments
- 🔐 **Admin Dashboard**: Manual payment verification and course management
- 📜 **Certificates**: Automated certificate generation upon course completion
- 🚀 **Modern UI**: Professional design with animations and responsive layout
- 🔒 **Secure Authentication**: Replit Auth integration with session management

## Quick Start (Development)

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd cryptotrade-academy
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up environment variables**
   ```bash
   # Database will be auto-provisioned by Replit
   # Add Stripe keys for payment processing (optional)
   ```

4. **Start the development server**
   ```bash
   npm run dev
   ```

## VPS Deployment (One-Click Setup)

### Prerequisites
- Ubuntu 20.04+ or Debian 11+ VPS
- Minimum 1GB RAM, 20GB storage
- Domain name (optional but recommended)

### Installation

1. **Upload project files to your VPS**
   ```bash
   scp -r * user@your-server:/home/user/cryptotrade-academy/
   ```

2. **Run the setup script**
   ```bash
   cd cryptotrade-academy
   chmod +x setup.sh
   ./setup.sh
   ```

3. **Configure environment variables**
   ```bash
   nano .env
   ```
   Update these critical values:
   - `REPL_ID`: Your Replit application ID
   - `REPLIT_DOMAINS`: Your domain name
   - `STRIPE_SECRET_KEY`: Stripe secret key (optional)
   - `VITE_STRIPE_PUBLIC_KEY`: Stripe public key (optional)

4. **Restart the application**
   ```bash
   docker-compose restart
   ```

5. **Create admin user**
   ```bash
   ./create-admin.sh your-email@domain.com
   ```

### What the Setup Script Does

- ✅ **System Updates**: Updates all packages
- ✅ **Docker Installation**: Installs Docker and Docker Compose
- ✅ **Security**: Configures firewall (UFW) and fail2ban
- ✅ **Database**: Sets up PostgreSQL with proper initialization
- ✅ **SSL Ready**: Nginx configuration for HTTPS
- ✅ **Monitoring**: System health checks every 5 minutes
- ✅ **Backups**: Automated daily backups at 2 AM
- ✅ **Auto-restart**: Systemd service for boot startup
- ✅ **Log Rotation**: Prevents log files from filling disk

## Architecture

### Backend
- **Node.js + Express**: RESTful API server
- **PostgreSQL**: Primary database with Drizzle ORM
- **Replit Auth**: OpenID Connect authentication
- **Stripe**: Payment processing (optional)

### Frontend
- **React 18 + TypeScript**: Modern React with full type safety
- **Tailwind CSS**: Utility-first styling with custom components
- **Radix UI**: Accessible component primitives
- **TanStack Query**: Server state management
- **Wouter**: Lightweight client-side routing

### Database Schema
- **Users**: Profile data with admin flags
- **Courses**: Three-tier course structure
- **Enrollments**: User-course relationships with payment tracking
- **Crypto Settings**: Admin-managed wallet addresses
- **Payment Requests**: Crypto payment verification workflow
- **Certificates**: Achievement tracking

## Admin Features

### Course Management
- Create, edit, and delete courses
- Set pricing and difficulty levels
- Track enrollment statistics

### Payment Management
- View all crypto payment requests
- Manually verify transactions
- Approve/reject payments with notes
- Automatic user enrollment upon approval

### User Management
- View all registered users
- Manually enroll users in courses
- Assign admin privileges
- Track user progress

### Crypto Wallet Management
- Add multiple cryptocurrency wallets
- Support for BTC, ETH, USDT, and more
- Network specification (mainnet, testnet, etc.)
- Enable/disable payment methods

## Crypto Payment Workflow

1. **User selects crypto payment** on course enrollment
2. **System displays wallet address** and payment amount
3. **User sends cryptocurrency** to provided address
4. **User submits payment proof** with transaction ID
5. **Admin reviews and verifies** transaction manually
6. **Upon approval**, user is automatically enrolled
7. **Certificate issued** upon course completion

## Security Features

- 🔒 **HTTPS Enforcement**: SSL/TLS encryption
- 🛡️ **Firewall Protection**: UFW configured
- 🚫 **DDoS Protection**: Fail2ban integration
- 🔐 **Secure Sessions**: HTTP-only cookies
- 💾 **Automated Backups**: Daily database and file backups
- 📊 **Monitoring**: Health checks and alerting

## Monitoring & Maintenance

### Logs
```bash
# View application logs
docker-compose logs -f

# View system logs
tail -f /var/log/syslog
```

### Backup & Restore
```bash
# Manual backup
./backup.sh

# Restore from backup
docker-compose exec -T db psql -U postgres cryptotrade_academy < backup_file.sql
```

### Updates
```bash
# Update application
git pull
docker-compose build
docker-compose up -d
```

## Environment Variables

### Required
- `DATABASE_URL`: PostgreSQL connection string
- `SESSION_SECRET`: Session encryption key
- `REPL_ID`: Replit application identifier
- `REPLIT_DOMAINS`: Allowed domains for auth

### Optional
- `STRIPE_SECRET_KEY`: Stripe payment processing
- `VITE_STRIPE_PUBLIC_KEY`: Stripe frontend integration
- `ISSUER_URL`: Custom OIDC provider (defaults to Replit)

## API Endpoints

### Public
- `GET /api/courses` - List all courses
- `GET /api/crypto-settings` - Available payment methods

### Authenticated
- `GET /api/auth/user` - Current user info
- `GET /api/enrollments` - User enrollments
- `POST /api/payment-request` - Submit crypto payment

### Admin Only
- `POST /api/admin/courses` - Create course
- `PUT /api/admin/courses/:id` - Update course
- `DELETE /api/admin/courses/:id` - Delete course
- `GET /api/admin/payment-requests` - Payment management
- `POST /api/admin/verify-payment` - Approve/reject payments

## Troubleshooting

### Common Issues

1. **Application won't start**
   ```bash
   # Check container logs
   docker-compose logs
   
   # Restart services
   docker-compose restart
   ```

2. **Database connection errors**
   ```bash
   # Check database status
   docker-compose exec db pg_isready -U postgres
   
   # Reset database
   docker-compose down -v
   docker-compose up -d
   ```

3. **Authentication issues**
   - Verify `REPL_ID` and `REPLIT_DOMAINS` in `.env`
   - Check domain configuration in Replit dashboard
   - Ensure SSL is properly configured

4. **Payment processing problems**
   - Verify Stripe keys in `.env`
   - Check Stripe webhook configuration
   - Review payment request logs

### Performance Optimization

- **Database**: Regular VACUUM and ANALYZE
- **Images**: Optimize uploaded images
- **Caching**: Enable Redis for session storage
- **CDN**: Use CloudFlare for static assets

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For technical support:
- Check the logs: `docker-compose logs -f`
- Review this documentation
- Submit an issue on GitHub

For business inquiries:
- Contact: admin@cryptotrade-academy.com