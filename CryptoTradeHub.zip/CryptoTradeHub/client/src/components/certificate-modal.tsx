import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Download, Share, Calendar, Award } from "lucide-react";

interface CertificateModalProps {
  certificate: {
    id: number;
    certificateId: string;
    finalScore: number;
    issuedAt: string;
    course: {
      name: string;
      level: string;
    };
  };
  user: {
    firstName?: string;
    lastName?: string;
    email?: string;
  } | null;
  onClose: () => void;
}

export default function CertificateModal({ certificate, user, onClose }: CertificateModalProps) {
  const handleDownload = () => {
    // In a real app, this would generate and download a PDF
    console.log("Downloading certificate:", certificate.certificateId);
  };

  const handleShare = () => {
    // In a real app, this would open share options
    if (navigator.share) {
      navigator.share({
        title: 'My Certificate',
        text: `I completed ${certificate.course.name} with a score of ${certificate.finalScore}%!`,
        url: window.location.href,
      });
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  const getUserName = () => {
    if (user?.firstName && user?.lastName) {
      return `${user.firstName} ${user.lastName}`;
    }
    return user?.email || 'Student';
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl">
        <DialogHeader>
          <DialogTitle>Certificate</DialogTitle>
        </DialogHeader>
        
        {/* Certificate Design */}
        <div className="certificate-bg border-8 border-primary rounded-lg p-12 text-center">
          <div className="mb-8">
            <h1 className="text-4xl font-bold text-primary mb-2">
              Certificate of Completion
            </h1>
            <p className="text-xl text-gray-600">CryptoTrade Academy</p>
          </div>
          
          <div className="mb-8">
            <p className="text-lg text-gray-700 mb-4">This is to certify that</p>
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              {getUserName()}
            </h2>
            <p className="text-lg text-gray-700 mb-4">has successfully completed the</p>
            <h3 className="text-2xl font-bold text-primary mb-4">
              {certificate.course.name}
            </h3>
            <p className="text-gray-600">
              with a score of{' '}
              <span className="font-bold text-emerald-500">
                {certificate.finalScore}%
              </span>
            </p>
          </div>

          <div className="flex justify-center items-center space-x-12 mb-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-amber-500 rounded-full flex items-center justify-center mx-auto mb-2">
                <Calendar className="w-8 h-8 text-white" />
              </div>
              <p className="text-sm text-gray-600">Completed</p>
              <p className="font-semibold">{formatDate(certificate.issuedAt)}</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-emerald-500 rounded-full flex items-center justify-center mx-auto mb-2">
                <Award className="w-8 h-8 text-white" />
              </div>
              <p className="text-sm text-gray-600">Certificate ID</p>
              <p className="font-semibold">{certificate.certificateId}</p>
            </div>
          </div>

          <div className="flex justify-center space-x-4">
            <Button 
              onClick={handleDownload}
              className="bg-primary hover:bg-blue-700 text-white"
            >
              <Download className="w-4 h-4 mr-2" />
              Download PDF
            </Button>
            <Button 
              onClick={handleShare}
              className="bg-emerald-500 hover:bg-emerald-600 text-white"
            >
              <Share className="w-4 h-4 mr-2" />
              Share Certificate
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
