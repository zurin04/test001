import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, Sprout, TrendingUp, Crown } from "lucide-react";

interface CourseCardProps {
  course: {
    id: number;
    name: string;
    description: string;
    level: string;
    price: string;
  };
  onEnroll: () => void;
  isPopular?: boolean;
}

export default function CourseCard({ course, onEnroll, isPopular }: CourseCardProps) {
  const getCourseIcon = (level: string) => {
    switch (level) {
      case "basic":
        return <Sprout className="w-8 h-8 text-white" />;
      case "intermediate":
        return <TrendingUp className="w-8 h-8 text-white" />;
      case "advanced":
        return <Crown className="w-8 h-8 text-white" />;
      default:
        return <Sprout className="w-8 h-8 text-white" />;
    }
  };

  const getCourseColor = (level: string) => {
    switch (level) {
      case "basic":
        return "bg-emerald-500";
      case "intermediate":
        return "bg-primary";
      case "advanced":
        return "bg-amber-500";
      default:
        return "bg-gray-500";
    }
  };

  const getCourseFeatures = (level: string) => {
    switch (level) {
      case "basic":
        return [
          "Introduction to Cryptocurrency",
          "Basic Trading Concepts",
          "Wallet Management",
          "5 Lessons + Quizzes",
          "Certificate of Completion"
        ];
      case "intermediate":
        return [
          "Technical Analysis",
          "Trading Strategies", 
          "Risk Management",
          "10 Lessons + Advanced Quizzes",
          "Professional Certificate"
        ];
      case "advanced":
        return [
          "Advanced Trading Strategies",
          "Portfolio Management",
          "DeFi & Future Markets",
          "15 Lessons + Expert Quizzes",
          "Master Trader Certificate"
        ];
      default:
        return [];
    }
  };

  const getPriceColor = (level: string) => {
    switch (level) {
      case "basic":
        return "text-emerald-500";
      case "intermediate":
        return "text-primary";
      case "advanced":
        return "text-amber-500";
      default:
        return "text-gray-500";
    }
  };

  const getButtonStyle = (level: string) => {
    switch (level) {
      case "basic":
        return "bg-emerald-500 hover:bg-emerald-600 text-white";
      case "intermediate":
        return "bg-primary hover:bg-blue-700 text-white";
      case "advanced":
        return "bg-amber-500 hover:bg-amber-600 text-black";
      default:
        return "bg-gray-500 hover:bg-gray-600 text-white";
    }
  };

  return (
    <Card className={`course-card relative ${isPopular ? 'border-2 border-primary transform scale-105' : ''}`}>
      {isPopular && (
        <div className="popular-badge">POPULAR</div>
      )}
      <CardContent className="p-8">
        <div className="text-center mb-6">
          <div className={`w-16 h-16 ${getCourseColor(course.level)} rounded-full flex items-center justify-center mx-auto mb-4`}>
            {getCourseIcon(course.level)}
          </div>
          <h3 className="text-2xl font-bold text-gray-900 mb-2">
            {course.name}
          </h3>
          <div className={`text-3xl font-bold mb-4 ${getPriceColor(course.level)}`}>
            {course.price === '0.00' ? 'FREE' : `$${course.price}`}
          </div>
          <p className="text-gray-600">{course.description}</p>
        </div>
        
        <ul className="space-y-3 mb-8">
          {getCourseFeatures(course.level).map((feature, idx) => (
            <li key={idx} className="flex items-center text-gray-700">
              <CheckCircle className={`w-5 h-5 mr-3 ${
                course.level === 'basic' ? 'text-emerald-500' :
                course.level === 'intermediate' ? 'text-primary' :
                'text-amber-500'
              }`} />
              {feature}
            </li>
          ))}
        </ul>
        
        <Button 
          onClick={onEnroll}
          className={`w-full py-3 font-semibold transition ${getButtonStyle(course.level)}`}
        >
          {course.price === '0.00' ? 'Start Free Course' : 'Enroll Now'}
        </Button>
      </CardContent>
    </Card>
  );
}
