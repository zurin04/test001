import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Download, BookOpen } from "lucide-react";

interface ProgressCardProps {
  enrollment: {
    id: number;
    courseId: number;
    completedAt: string | null;
    course: {
      name: string;
      level: string;
    };
    progress: {
      progressPercentage: number;
    };
  };
  onContinue: () => void;
  onDownloadCertificate?: () => void;
}

export default function ProgressCard({ enrollment, onContinue, onDownloadCertificate }: ProgressCardProps) {
  const getStatusBadge = () => {
    if (enrollment.completedAt) {
      return <Badge className="bg-emerald-500">Completed</Badge>;
    } else if (enrollment.progress.progressPercentage > 0) {
      return <Badge variant="outline" className="border-primary text-primary">In Progress</Badge>;
    } else {
      return <Badge variant="secondary">Not Started</Badge>;
    }
  };

  return (
    <Card className="course-card">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-gray-900">
            {enrollment.course.name}
          </h3>
          {getStatusBadge()}
        </div>
        
        <div className="mb-4">
          <div className="flex justify-between text-sm text-gray-600 mb-2">
            <span>Progress</span>
            <span>{enrollment.progress.progressPercentage}%</span>
          </div>
          <Progress 
            value={enrollment.progress.progressPercentage} 
            className="h-2"
          />
        </div>
        
        <div className="flex items-center justify-between">
          {enrollment.completedAt ? (
            <>
              <span className="text-sm text-gray-600">Certificate earned</span>
              <Button
                size="sm"
                className="bg-emerald-500 hover:bg-emerald-600"
                onClick={onDownloadCertificate}
              >
                <Download className="w-4 h-4 mr-2" />
                Download
              </Button>
            </>
          ) : (
            <>
              <span className="text-sm text-gray-600">
                {enrollment.progress.progressPercentage === 0 ? 'Ready to start' : 'Continue learning'}
              </span>
              <Button 
                size="sm" 
                className="bg-primary hover:bg-blue-700"
                onClick={onContinue}
              >
                <BookOpen className="w-4 h-4 mr-2" />
                {enrollment.progress.progressPercentage === 0 ? 'Start' : 'Continue'}
              </Button>
            </>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
