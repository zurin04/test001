import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/useAuth";
import { 
  Users, 
  BookOpen, 
  CreditCard, 
  Settings, 
  CheckCircle, 
  XCircle, 
  Clock,
  Plus,
  Edit,
  Trash2
} from "lucide-react";

export default function Admin() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [selectedUserId, setSelectedUserId] = useState("");
  const [selectedCourseId, setSelectedCourseId] = useState("");
  const [enrollmentNotes, setEnrollmentNotes] = useState("");
  const [verificationNotes, setVerificationNotes] = useState("");

  // New crypto setting form
  const [newCryptoSetting, setNewCryptoSetting] = useState({
    currency: "",
    walletAddress: "",
    networkName: "",
  });

  // New course form
  const [newCourse, setNewCourse] = useState({
    name: "",
    description: "",
    level: "basic",
    price: "0.00",
  });

  // Edit course form
  const [editingCourse, setEditingCourse] = useState<any>(null);

  const { data: users = [] } = useQuery({
    queryKey: ["/api/admin/users"],
  });

  const { data: courses = [] } = useQuery({
    queryKey: ["/api/courses"],
  });

  const { data: enrollments = [] } = useQuery({
    queryKey: ["/api/admin/enrollments"],
  });

  const { data: paymentRequests = [] } = useQuery({
    queryKey: ["/api/admin/payment-requests"],
  });

  const { data: cryptoSettings = [] } = useQuery({
    queryKey: ["/api/crypto-settings"],
  });

  const enrollUserMutation = useMutation({
    mutationFn: async (data: { userId: string; courseId: number; notes: string }) => {
      await apiRequest("POST", "/api/admin/enroll-user", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/enrollments"] });
      setSelectedUserId("");
      setSelectedCourseId("");
      setEnrollmentNotes("");
      toast({
        title: "Success",
        description: "User enrolled successfully",
      });
    },
  });

  const verifyPaymentMutation = useMutation({
    mutationFn: async (data: { requestId: number; status: string; notes: string }) => {
      await apiRequest("POST", "/api/admin/verify-payment", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/payment-requests"] });
      toast({
        title: "Success",
        description: "Payment request updated",
      });
    },
  });

  const createCryptoSettingMutation = useMutation({
    mutationFn: async (data: any) => {
      await apiRequest("POST", "/api/admin/crypto-settings", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/crypto-settings"] });
      setNewCryptoSetting({ currency: "", walletAddress: "", networkName: "" });
      toast({
        title: "Success",
        description: "Crypto setting created",
      });
    },
  });

  const deleteCryptoSettingMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/admin/crypto-settings/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/crypto-settings"] });
      toast({
        title: "Success",
        description: "Crypto setting deleted",
      });
    },
  });

  const createCourseMutation = useMutation({
    mutationFn: async (data: any) => {
      await apiRequest("POST", "/api/admin/courses", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/courses"] });
      setNewCourse({ name: "", description: "", level: "basic", price: "0.00" });
      toast({
        title: "Success",
        description: "Course created successfully",
      });
    },
  });

  const updateCourseMutation = useMutation({
    mutationFn: async (data: { id: number; course: any }) => {
      await apiRequest("PUT", `/api/admin/courses/${data.id}`, data.course);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/courses"] });
      setEditingCourse(null);
      toast({
        title: "Success",
        description: "Course updated successfully",
      });
    },
  });

  const deleteCourseMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/admin/courses/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/courses"] });
      toast({
        title: "Success",
        description: "Course deleted successfully",
      });
    },
  });

  const handleEnrollUser = () => {
    if (!selectedUserId || !selectedCourseId) {
      toast({
        title: "Missing Information",
        description: "Please select both user and course",
        variant: "destructive",
      });
      return;
    }

    enrollUserMutation.mutate({
      userId: selectedUserId,
      courseId: parseInt(selectedCourseId),
      notes: enrollmentNotes,
    });
  };

  const handleVerifyPayment = (requestId: number, status: string) => {
    verifyPaymentMutation.mutate({
      requestId,
      status,
      notes: verificationNotes,
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "verified":
        return "bg-emerald-500";
      case "rejected":
        return "bg-red-500";
      default:
        return "bg-amber-500";
    }
  };

  const getPaymentMethodColor = (method: string) => {
    switch (method) {
      case "stripe":
        return "bg-blue-500";
      case "crypto":
        return "bg-orange-500";
      case "admin":
        return "bg-purple-500";
      default:
        return "bg-gray-500";
    }
  };

  if (!user?.isAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="max-w-md mx-4">
          <CardContent className="pt-6 text-center">
            <h2 className="text-xl font-bold mb-4">Access Denied</h2>
            <p className="text-gray-600">You don't have admin permissions to access this page.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen crypto-light py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Admin Dashboard</h1>
          <p className="text-gray-600">Manage users, enrollments, and payments</p>
        </div>

        <Tabs defaultValue="courses" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="courses" className="flex items-center space-x-2">
              <BookOpen className="w-4 h-4" />
              <span>Courses</span>
            </TabsTrigger>
            <TabsTrigger value="users" className="flex items-center space-x-2">
              <Users className="w-4 h-4" />
              <span>Users</span>
            </TabsTrigger>
            <TabsTrigger value="enrollments" className="flex items-center space-x-2">
              <BookOpen className="w-4 h-4" />
              <span>Enrollments</span>
            </TabsTrigger>
            <TabsTrigger value="payments" className="flex items-center space-x-2">
              <CreditCard className="w-4 h-4" />
              <span>Payments</span>
            </TabsTrigger>
            <TabsTrigger value="settings" className="flex items-center space-x-2">
              <Settings className="w-4 h-4" />
              <span>Settings</span>
            </TabsTrigger>
          </TabsList>

          {/* Courses Tab */}
          <TabsContent value="courses">
            <div className="grid lg:grid-cols-3 gap-6">
              <Card className="lg:col-span-2">
                <CardHeader>
                  <CardTitle>Manage Courses</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {courses.map((course: any) => (
                      <div key={course.id} className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="flex-1">
                          <h3 className="font-semibold">{course.name}</h3>
                          <p className="text-sm text-gray-600">{course.description}</p>
                          <div className="flex space-x-2 mt-2">
                            <Badge className={getPaymentMethodColor(course.level)}>
                              {course.level}
                            </Badge>
                            <Badge variant="secondary">
                              ${course.price}
                            </Badge>
                          </div>
                        </div>
                        <div className="flex space-x-2">
                          <Button
                            onClick={() => setEditingCourse(course)}
                            variant="outline"
                            size="sm"
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button
                            onClick={() => deleteCourseMutation.mutate(course.id)}
                            variant="destructive"
                            size="sm"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>{editingCourse ? 'Edit Course' : 'Add New Course'}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label>Course Name</Label>
                    <Input
                      value={editingCourse ? editingCourse.name : newCourse.name}
                      onChange={(e) => {
                        if (editingCourse) {
                          setEditingCourse({ ...editingCourse, name: e.target.value });
                        } else {
                          setNewCourse({ ...newCourse, name: e.target.value });
                        }
                      }}
                      placeholder="Enter course name"
                    />
                  </div>

                  <div>
                    <Label>Description</Label>
                    <Textarea
                      value={editingCourse ? editingCourse.description : newCourse.description}
                      onChange={(e) => {
                        if (editingCourse) {
                          setEditingCourse({ ...editingCourse, description: e.target.value });
                        } else {
                          setNewCourse({ ...newCourse, description: e.target.value });
                        }
                      }}
                      placeholder="Enter course description"
                    />
                  </div>

                  <div>
                    <Label>Level</Label>
                    <Select 
                      value={editingCourse ? editingCourse.level : newCourse.level} 
                      onValueChange={(value) => {
                        if (editingCourse) {
                          setEditingCourse({ ...editingCourse, level: value });
                        } else {
                          setNewCourse({ ...newCourse, level: value });
                        }
                      }}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select level" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="basic">Basic</SelectItem>
                        <SelectItem value="intermediate">Intermediate</SelectItem>
                        <SelectItem value="advanced">Advanced</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label>Price (USD)</Label>
                    <Input
                      type="number"
                      step="0.01"
                      value={editingCourse ? editingCourse.price : newCourse.price}
                      onChange={(e) => {
                        if (editingCourse) {
                          setEditingCourse({ ...editingCourse, price: e.target.value });
                        } else {
                          setNewCourse({ ...newCourse, price: e.target.value });
                        }
                      }}
                      placeholder="0.00"
                    />
                  </div>

                  <div className="flex space-x-2">
                    {editingCourse ? (
                      <>
                        <Button
                          onClick={() => updateCourseMutation.mutate({ id: editingCourse.id, course: editingCourse })}
                          disabled={updateCourseMutation.isPending}
                          className="flex-1"
                        >
                          Update Course
                        </Button>
                        <Button
                          onClick={() => setEditingCourse(null)}
                          variant="outline"
                        >
                          Cancel
                        </Button>
                      </>
                    ) : (
                      <Button
                        onClick={() => createCourseMutation.mutate(newCourse)}
                        disabled={createCourseMutation.isPending}
                        className="w-full"
                      >
                        Add Course
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Users Tab */}
          <TabsContent value="users">
            <div className="grid lg:grid-cols-3 gap-6">
              <Card className="lg:col-span-2">
                <CardHeader>
                  <CardTitle>All Users</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {users.map((user: any) => (
                      <div key={user.id} className="flex items-center justify-between p-4 border rounded-lg">
                        <div>
                          <h3 className="font-semibold">{user.firstName} {user.lastName}</h3>
                          <p className="text-sm text-gray-600">{user.email}</p>
                          <div className="flex space-x-2 mt-2">
                            {user.isAdmin && (
                              <Badge className="bg-purple-500">Admin</Badge>
                            )}
                            <Badge variant="secondary">
                              Joined {new Date(user.createdAt).toLocaleDateString()}
                            </Badge>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Manual Enrollment</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label>Select User</Label>
                    <Select value={selectedUserId} onValueChange={setSelectedUserId}>
                      <SelectTrigger>
                        <SelectValue placeholder="Choose a user" />
                      </SelectTrigger>
                      <SelectContent>
                        {users.map((user: any) => (
                          <SelectItem key={user.id} value={user.id}>
                            {user.firstName} {user.lastName} ({user.email})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label>Select Course</Label>
                    <Select value={selectedCourseId} onValueChange={setSelectedCourseId}>
                      <SelectTrigger>
                        <SelectValue placeholder="Choose a course" />
                      </SelectTrigger>
                      <SelectContent>
                        {courses.map((course: any) => (
                          <SelectItem key={course.id} value={course.id.toString()}>
                            {course.name} (${course.price})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label>Notes (Optional)</Label>
                    <Textarea
                      value={enrollmentNotes}
                      onChange={(e) => setEnrollmentNotes(e.target.value)}
                      placeholder="Add any notes about this enrollment..."
                    />
                  </div>

                  <Button
                    onClick={handleEnrollUser}
                    disabled={enrollUserMutation.isPending}
                    className="w-full"
                  >
                    {enrollUserMutation.isPending ? "Enrolling..." : "Enroll User"}
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Enrollments Tab */}
          <TabsContent value="enrollments">
            <Card>
              <CardHeader>
                <CardTitle>All Enrollments</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {enrollments.map((enrollment: any) => (
                    <div key={enrollment.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div>
                        <h3 className="font-semibold">
                          {enrollment.user?.firstName} {enrollment.user?.lastName}
                        </h3>
                        <p className="text-sm text-gray-600">{enrollment.course?.name}</p>
                        <div className="flex space-x-2 mt-2">
                          <Badge className={getPaymentMethodColor(enrollment.paymentMethod)}>
                            {enrollment.paymentMethod}
                          </Badge>
                          {enrollment.completedAt ? (
                            <Badge className="bg-emerald-500">Completed</Badge>
                          ) : (
                            <Badge variant="secondary">In Progress</Badge>
                          )}
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-gray-600">
                          Enrolled: {new Date(enrollment.enrolledAt).toLocaleDateString()}
                        </p>
                        {enrollment.adminApprovalNotes && (
                          <p className="text-xs text-gray-500 mt-1">
                            Admin Notes: {enrollment.adminApprovalNotes}
                          </p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Payments Tab */}
          <TabsContent value="payments">
            <Card>
              <CardHeader>
                <CardTitle>Crypto Payment Requests</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {paymentRequests.map((request: any) => (
                    <div key={request.id} className="p-4 border rounded-lg">
                      <div className="flex items-center justify-between mb-4">
                        <div>
                          <h3 className="font-semibold">
                            {request.user?.firstName} {request.user?.lastName}
                          </h3>
                          <p className="text-sm text-gray-600">{request.course?.name}</p>
                        </div>
                        <Badge className={getStatusColor(request.status)}>
                          {request.status}
                        </Badge>
                      </div>

                      <div className="grid md:grid-cols-2 gap-4 mb-4">
                        <div>
                          <p><strong>Currency:</strong> {request.cryptoCurrency}</p>
                          <p><strong>Amount:</strong> {request.amount}</p>
                          <p><strong>USD Value:</strong> ${request.usdAmount}</p>
                        </div>
                        <div>
                          <p><strong>Transaction ID:</strong></p>
                          <p className="font-mono text-sm break-all">{request.transactionId}</p>
                          <p><strong>Wallet:</strong></p>
                          <p className="font-mono text-sm break-all">{request.walletAddress}</p>
                        </div>
                      </div>

                      {request.status === "pending" && (
                        <div className="space-y-3">
                          <Textarea
                            value={verificationNotes}
                            onChange={(e) => setVerificationNotes(e.target.value)}
                            placeholder="Add verification notes..."
                          />
                          <div className="flex space-x-2">
                            <Button
                              onClick={() => handleVerifyPayment(request.id, "verified")}
                              disabled={verifyPaymentMutation.isPending}
                              className="bg-emerald-500 hover:bg-emerald-600"
                            >
                              <CheckCircle className="w-4 h-4 mr-2" />
                              Approve
                            </Button>
                            <Button
                              onClick={() => handleVerifyPayment(request.id, "rejected")}
                              disabled={verifyPaymentMutation.isPending}
                              variant="destructive"
                            >
                              <XCircle className="w-4 h-4 mr-2" />
                              Reject
                            </Button>
                          </div>
                        </div>
                      )}

                      {request.adminNotes && (
                        <div className="mt-3 p-3 bg-gray-50 rounded-lg">
                          <p className="text-sm"><strong>Admin Notes:</strong> {request.adminNotes}</p>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings">
            <div className="grid lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    Crypto Wallet Settings
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button size="sm">
                          <Plus className="w-4 h-4 mr-2" />
                          Add Wallet
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Add Crypto Wallet</DialogTitle>
                        </DialogHeader>
                        <div className="space-y-4">
                          <div>
                            <Label>Currency</Label>
                            <Input
                              value={newCryptoSetting.currency}
                              onChange={(e) => setNewCryptoSetting({
                                ...newCryptoSetting,
                                currency: e.target.value
                              })}
                              placeholder="BTC, ETH, USDT, etc."
                            />
                          </div>
                          <div>
                            <Label>Wallet Address</Label>
                            <Input
                              value={newCryptoSetting.walletAddress}
                              onChange={(e) => setNewCryptoSetting({
                                ...newCryptoSetting,
                                walletAddress: e.target.value
                              })}
                              placeholder="Enter wallet address"
                              className="font-mono"
                            />
                          </div>
                          <div>
                            <Label>Network</Label>
                            <Input
                              value={newCryptoSetting.networkName}
                              onChange={(e) => setNewCryptoSetting({
                                ...newCryptoSetting,
                                networkName: e.target.value
                              })}
                              placeholder="mainnet, BSC, Polygon, etc."
                            />
                          </div>
                          <Button
                            onClick={() => createCryptoSettingMutation.mutate(newCryptoSetting)}
                            disabled={createCryptoSettingMutation.isPending}
                            className="w-full"
                          >
                            Add Wallet
                          </Button>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {cryptoSettings.map((setting: any) => (
                      <div key={setting.id} className="p-4 border rounded-lg">
                        <div className="flex items-center justify-between">
                          <div>
                            <h3 className="font-semibold">{setting.currency}</h3>
                            <p className="text-sm text-gray-600">{setting.networkName}</p>
                            <p className="font-mono text-xs text-gray-500 break-all">
                              {setting.walletAddress}
                            </p>
                          </div>
                          <Button
                            onClick={() => deleteCryptoSettingMutation.mutate(setting.id)}
                            variant="destructive"
                            size="sm"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Statistics</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between">
                      <span>Total Users:</span>
                      <span className="font-semibold">{users.length}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Total Enrollments:</span>
                      <span className="font-semibold">{enrollments.length}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Pending Payments:</span>
                      <span className="font-semibold">
                        {paymentRequests.filter((r: any) => r.status === "pending").length}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Verified Payments:</span>
                      <span className="font-semibold">
                        {paymentRequests.filter((r: any) => r.status === "verified").length}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}