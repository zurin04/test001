import { useParams, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { ArrowLeft, PlayCircle, FileText, CheckCircle, Clock, Award } from "lucide-react";
import { Link } from "wouter";

export default function CourseContent() {
  const { courseId } = useParams();
  const [, setLocation] = useLocation();

  const { data: course, isLoading } = useQuery({
    queryKey: ["/api/courses", courseId],
  });

  const { data: courseContent } = useQuery({
    queryKey: ["/api/courses", courseId, "content"],
    enabled: !!courseId,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen crypto-light py-12">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="animate-pulse">
            <div className="h-8 bg-gray-200 rounded w-1/4 mb-4"></div>
            <div className="h-4 bg-gray-200 rounded w-1/2 mb-8"></div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2">
                <div className="h-64 bg-gray-200 rounded-lg"></div>
              </div>
              <div className="h-96 bg-gray-200 rounded-lg"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!course) {
    return (
      <div className="min-h-screen crypto-light py-12">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Course Not Found</h1>
            <Link href="/">
              <Button>Back to Home</Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const getLevelColor = (level?: string) => {
    if (!level) return "bg-gray-100 text-gray-800";
    switch (level) {
      case "basic":
        return "bg-green-100 text-green-800";
      case "intermediate":
        return "bg-yellow-100 text-yellow-800";
      case "advanced":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getIconForContent = (type: string) => {
    switch (type) {
      case "lesson":
        return <PlayCircle className="w-4 h-4" />;
      case "quiz":
        return <FileText className="w-4 h-4" />;
      case "exam":
        return <Award className="w-4 h-4" />;
      default:
        return <FileText className="w-4 h-4" />;
    }
  };

  return (
    <div className="min-h-screen crypto-bg py-12">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex items-center mb-8">
          <Link href="/">
            <Button variant="ghost" size="sm" className="mr-4">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Home
            </Button>
          </Link>
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-2">
              <h1 className="text-3xl font-bold font-poppins text-foreground">{course?.name || 'Course'}</h1>
              <Badge className={getLevelColor(course?.level)}>
                {course?.level ? course.level.charAt(0).toUpperCase() + course.level.slice(1) : 'Unknown'}
              </Badge>
            </div>
            <p className="text-muted-foreground font-roboto">{course?.description || 'Course description not available'}</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            <Card className="course-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 font-poppins text-foreground">
                  <FileText className="w-5 h-5 text-primary" />
                  Course Curriculum
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {courseContent?.categories?.map((category: any, categoryIndex: number) => (
                  <div key={category.id} className="border-l-4 border-primary pl-4">
                    <h3 className="text-lg font-semibold font-poppins text-foreground mb-3">
                      {categoryIndex + 1}. {category.name}
                    </h3>
                    <p className="text-muted-foreground mb-4 font-roboto">{category.description}</p>
                    
                    <div className="space-y-3">
                      {/* Lessons */}
                      {category.lessons?.map((lesson: any, lessonIndex: number) => (
                        <div key={lesson.id} className="flex items-center gap-3 p-3 glass rounded-lg">
                          <div className="text-primary">
                            {getIconForContent("lesson")}
                          </div>
                          <div className="flex-1">
                            <h4 className="font-medium font-poppins text-foreground">
                              Lesson {lessonIndex + 1}: {lesson.title}
                            </h4>
                            <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1 font-roboto">
                              <Clock className="w-3 h-3" />
                              {lesson.duration || 15} minutes
                            </div>
                          </div>
                        </div>
                      ))}
                      
                      {/* Category Quiz */}
                      {category.quizzes?.map((quiz: any) => (
                        <div key={quiz.id} className="flex items-center gap-3 p-3 glass rounded-lg border border-primary/20">
                          <div className="text-cyan-400">
                            {getIconForContent("quiz")}
                          </div>
                          <div className="flex-1">
                            <h4 className="font-medium font-poppins text-foreground">{quiz.title}</h4>
                            <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1 font-roboto">
                              <FileText className="w-3 h-3" />
                              {quiz.questions?.length || 0} questions • {quiz.passingScore}% to pass
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}

                {/* Course-level Exams */}
                {courseContent?.exams?.map((exam: any) => (
                  <div key={exam.id} className="border-l-4 border-purple-500 pl-4">
                    <div className="flex items-center gap-3 p-4 bg-purple-50 rounded-lg">
                      {getIconForContent("exam")}
                      <div className="flex-1">
                        <h4 className="font-medium text-gray-900">{exam.title}</h4>
                        <p className="text-gray-600 text-sm mt-1">{exam.description}</p>
                        <div className="flex items-center gap-4 text-sm text-gray-500 mt-2">
                          <span className="flex items-center gap-1">
                            <FileText className="w-3 h-3" />
                            {exam.questions?.length || 0} questions
                          </span>
                          <span className="flex items-center gap-1">
                            <Award className="w-3 h-3" />
                            {exam.passingScore}% to pass
                          </span>
                          {exam.timeLimit && (
                            <span className="flex items-center gap-1">
                              <Clock className="w-3 h-3" />
                              {exam.timeLimit} minutes
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Course Info */}
            <Card className="course-card">
              <CardHeader>
                <CardTitle className="font-poppins text-foreground">Course Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground font-roboto">Price</span>
                  <span className="font-semibold text-lg font-poppins text-primary">
                    {course?.price === "0.00" ? "Free" : `$${course?.price || '0.00'}`}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Level</span>
                  <Badge className={getLevelColor(course?.level)}>
                    {course?.level ? course.level.charAt(0).toUpperCase() + course.level.slice(1) : 'Unknown'}
                  </Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Lessons</span>
                  <span className="font-medium">
                    {courseContent?.categories?.reduce((total: number, cat: any) => 
                      total + (cat.lessons?.length || 0), 0) || 0}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Quizzes</span>
                  <span className="font-medium">
                    {courseContent?.categories?.reduce((total: number, cat: any) => 
                      total + (cat.quizzes?.length || 0), 0) || 0}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Final Exam</span>
                  <span className="font-medium">
                    {courseContent?.exams?.filter((exam: any) => exam.isFinalExam)?.length || 0}
                  </span>
                </div>
              </CardContent>
            </Card>

            {/* Enrollment */}
            <Card className="course-card">
              <CardHeader>
                <CardTitle className="font-poppins text-foreground">Get Started</CardTitle>
              </CardHeader>
              <CardContent>
                {course?.price === "0.00" ? (
                  <Button 
                    className="w-full btn-primary" 
                    size="lg"
                    onClick={async () => {
                      try {
                        const response = await fetch('/api/enroll', {
                          method: 'POST',
                          headers: {
                            'Content-Type': 'application/json',
                          },
                          body: JSON.stringify({
                            courseId: course.id,
                            paymentIntentId: null,
                          }),
                        });

                        if (response.ok) {
                          alert("Successfully enrolled in the course!");
                          window.location.href = '/';
                        } else {
                          const error = await response.json();
                          alert(error.message || "Failed to enroll");
                        }
                      } catch (error) {
                        alert("Network error occurred");
                      }
                    }}
                  >
                    Enroll for Free
                  </Button>
                ) : (
                  <div className="space-y-3">
                    <Link href={`/checkout/${course?.id}`}>
                      <Button className="w-full btn-primary" size="lg">
                        💳 Enroll with Card - ${course?.price}
                      </Button>
                    </Link>
                    <Link href={`/crypto-payment/${course?.id}`}>
                      <Button className="w-full btn-crypto" size="lg">
                        ₿ Pay with Crypto - ${course?.price}
                      </Button>
                    </Link>
                  </div>
                )}
                <p className="text-sm text-gray-500 mt-3 text-center">
                  Complete the final exam with 70% or higher to earn your certificate
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}