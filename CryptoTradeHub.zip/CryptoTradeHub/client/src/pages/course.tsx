import { useParams, useLocation, Link } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { ArrowLeft, CheckCircle, Play, Clock, User, Bookmark } from "lucide-react";

export default function Course() {
  const { id } = useParams();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [currentLessonId, setCurrentLessonId] = useState<number | null>(null);

  const { data: courseData, isLoading } = useQuery({
    queryKey: [`/api/courses/${id}`],
    enabled: !!id,
  });

  const progressMutation = useMutation({
    mutationFn: async ({ lessonId, completed }: { lessonId: number; completed: boolean }) => {
      await apiRequest("POST", "/api/progress", { lessonId, completed });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/courses/${id}`] });
      queryClient.invalidateQueries({ queryKey: ["/api/enrollments"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update progress",
        variant: "destructive",
      });
    },
  });

  useEffect(() => {
    if (courseData?.categories?.length > 0) {
      // Find first incomplete lesson or first lesson
      let firstIncompleteLesson = null;
      
      for (const category of courseData.categories) {
        for (const lesson of category.lessons) {
          if (!lesson.completed) {
            firstIncompleteLesson = lesson;
            break;
          }
        }
        if (firstIncompleteLesson) break;
      }
      
      if (firstIncompleteLesson) {
        setCurrentLessonId(firstIncompleteLesson.id);
      } else if (courseData.categories[0]?.lessons?.length > 0) {
        setCurrentLessonId(courseData.categories[0].lessons[0].id);
      }
    }
  }, [courseData]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  if (!courseData) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="max-w-md mx-4">
          <CardContent className="pt-6 text-center">
            <h2 className="text-xl font-bold mb-4">Course Not Found</h2>
            <p className="text-gray-600 mb-4">You may not be enrolled in this course.</p>
            <Link href="/">
              <Button>Back to Home</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  const currentLesson = courseData.categories
    ?.flatMap((cat: any) => cat.lessons)
    ?.find((lesson: any) => lesson.id === currentLessonId);

  const currentCategory = courseData.categories?.find((cat: any) =>
    cat.lessons.some((lesson: any) => lesson.id === currentLessonId)
  );

  const handleLessonComplete = (lessonId: number) => {
    progressMutation.mutate({ lessonId, completed: true });
  };

  const handleTakeQuiz = () => {
    if (currentCategory?.quizzes?.length > 0) {
      setLocation(`/quiz/${currentCategory.quizzes[0].id}`);
    }
  };

  const getCategoryProgress = (category: any) => {
    const totalLessons = category.lessons.length;
    const completedLessons = category.lessons.filter((lesson: any) => lesson.completed).length;
    return totalLessons > 0 ? Math.round((completedLessons / totalLessons) * 100) : 0;
  };

  return (
    <div className="min-h-screen crypto-light py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex items-center mb-8">
          <Link href="/">
            <Button variant="ghost" size="sm" className="mr-4">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Dashboard
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">{courseData.name}</h1>
            <p className="text-gray-600">{courseData.description}</p>
          </div>
        </div>

        <div className="grid lg:grid-cols-4 gap-8">
          {/* Course Navigation */}
          <div className="lg:col-span-1">
            <Card className="sticky top-24">
              <CardHeader>
                <CardTitle className="text-lg">Course Content</CardTitle>
                <div className="text-sm text-gray-600">
                  Progress: {courseData.progress?.progressPercentage || 0}%
                </div>
                <Progress value={courseData.progress?.progressPercentage || 0} className="h-2" />
              </CardHeader>
              <CardContent className="space-y-2">
                {courseData.categories?.map((category: any, catIndex: number) => (
                  <div key={category.id}>
                    <div className="font-medium text-gray-900 mb-2 text-sm">
                      {catIndex + 1}. {category.name}
                    </div>
                    <div className="ml-4 space-y-1">
                      {category.lessons.map((lesson: any, lessonIndex: number) => (
                        <button
                          key={lesson.id}
                          onClick={() => setCurrentLessonId(lesson.id)}
                          className={`w-full text-left p-2 rounded-lg text-sm transition-colors ${
                            currentLessonId === lesson.id
                              ? 'bg-blue-50 border border-blue-200 text-blue-800'
                              : lesson.completed
                              ? 'bg-emerald-50 border border-emerald-200 text-emerald-800'
                              : 'bg-gray-50 border border-gray-200 text-gray-600 hover:bg-gray-100'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <span className="truncate">
                              {catIndex + 1}.{lessonIndex + 1} {lesson.title}
                            </span>
                            {lesson.completed ? (
                              <CheckCircle className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                            ) : currentLessonId === lesson.id ? (
                              <Play className="w-4 h-4 text-blue-600 flex-shrink-0" />
                            ) : null}
                          </div>
                        </button>
                      ))}
                    </div>
                    <div className="ml-4 mt-2">
                      <div className="text-xs text-gray-500 mb-1">
                        Progress: {getCategoryProgress(category)}%
                      </div>
                      <Progress value={getCategoryProgress(category)} className="h-1" />
                    </div>
                    <Separator className="my-3" />
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            <Card>
              <CardContent className="p-8">
                {currentLesson && (
                  <>
                    <div className="mb-8">
                      <h2 className="text-2xl font-bold text-gray-900 mb-4">
                        {currentLesson.title}
                      </h2>
                      <div className="flex items-center space-x-4 text-sm text-gray-600 mb-6">
                        <span className="flex items-center">
                          <Clock className="w-4 h-4 mr-1" />
                          {currentLesson.duration || 15} min read
                        </span>
                        <span className="flex items-center">
                          <User className="w-4 h-4 mr-1" />
                          {courseData.level}
                        </span>
                        <span className="flex items-center">
                          <Bookmark className="w-4 h-4 mr-1" />
                          Lesson {courseData.categories
                            ?.flatMap((cat: any) => cat.lessons)
                            ?.findIndex((lesson: any) => lesson.id === currentLessonId) + 1} of{' '}
                          {courseData.categories?.reduce((total: number, cat: any) => total + cat.lessons.length, 0)}
                        </span>
                      </div>
                    </div>

                    {/* Lesson Content */}
                    <div className="prose max-w-none mb-8">
                      <div 
                        dangerouslySetInnerHTML={{ __html: currentLesson.content }} 
                        className="text-gray-700 leading-relaxed"
                      />
                    </div>

                    {/* Lesson Navigation */}
                    <div className="flex justify-between items-center pt-8 border-t border-gray-200">
                      <div>
                        {!currentLesson.completed && (
                          <Button
                            onClick={() => handleLessonComplete(currentLesson.id)}
                            disabled={progressMutation.isPending}
                            className="bg-emerald-500 hover:bg-emerald-600"
                          >
                            {progressMutation.isPending ? 'Marking...' : 'Mark as Complete'}
                          </Button>
                        )}
                      </div>
                      <div className="space-x-4">
                        {currentCategory?.quizzes?.length > 0 && (
                          <Button 
                            onClick={handleTakeQuiz}
                            className="bg-primary hover:bg-blue-700"
                          >
                            Take Quiz
                          </Button>
                        )}
                        {courseData.finalExam && courseData.progress?.progressPercentage === 100 && (
                          <Button 
                            onClick={() => setLocation(`/quiz/${courseData.finalExam.id}`)}
                            className="bg-amber-500 hover:bg-amber-600"
                          >
                            Take Final Exam
                          </Button>
                        )}
                      </div>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
