import { useParams, useLocation } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { ArrowLeft, Copy, Upload, CheckCircle, Clock, AlertCircle } from "lucide-react";
import { Link } from "wouter";

export default function CryptoPayment() {
  const { courseId } = useParams();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [selectedCurrency, setSelectedCurrency] = useState("");
  const [transactionId, setTransactionId] = useState("");
  const [amount, setAmount] = useState("");
  const [proofImageUrl, setProofImageUrl] = useState("");

  const { data: course, isLoading: courseLoading } = useQuery({
    queryKey: [`/api/courses`],
    select: (data: any[]) => data.find((c: any) => c.id === parseInt(courseId || "0")),
    enabled: !!courseId,
  });

  const { data: cryptoSettings = [] } = useQuery({
    queryKey: ["/api/crypto-settings"],
  });

  const { data: paymentRequests = [] } = useQuery({
    queryKey: ["/api/payment-requests"],
  });

  const createPaymentRequestMutation = useMutation({
    mutationFn: async (requestData: any) => {
      await apiRequest("POST", "/api/payment-request", requestData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/payment-requests"] });
      toast({
        title: "Payment Request Submitted",
        description: "Your crypto payment request has been submitted for verification.",
      });
      setLocation("/");
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to submit payment request",
        variant: "destructive",
      });
    },
  });

  const handleSubmitPayment = () => {
    if (!selectedCurrency || !transactionId || !amount) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }

    const selectedSetting = cryptoSettings.find((s: any) => s.currency === selectedCurrency);
    if (!selectedSetting) {
      toast({
        title: "Invalid Currency",
        description: "Selected currency is not available",
        variant: "destructive",
      });
      return;
    }

    createPaymentRequestMutation.mutate({
      courseId: parseInt(courseId || "0"),
      cryptoCurrency: selectedCurrency,
      walletAddress: selectedSetting.walletAddress,
      transactionId,
      amount: parseFloat(amount),
      usdAmount: parseFloat(course?.price || "0"),
      proofImageUrl,
    });
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied",
      description: "Wallet address copied to clipboard",
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "verified":
        return "bg-emerald-500";
      case "rejected":
        return "bg-red-500";
      default:
        return "bg-amber-500";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "verified":
        return <CheckCircle className="w-4 h-4" />;
      case "rejected":
        return <AlertCircle className="w-4 h-4" />;
      default:
        return <Clock className="w-4 h-4" />;
    }
  };

  if (courseLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  if (!course) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="max-w-md mx-4">
          <CardContent className="pt-6 text-center">
            <h2 className="text-xl font-bold mb-4">Course Not Found</h2>
            <p className="text-gray-600 mb-4">The course you're trying to purchase doesn't exist.</p>
            <Link href="/">
              <Button>Back to Home</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen crypto-light py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex items-center mb-8">
          <Link href="/">
            <Button variant="ghost" size="sm" className="mr-4">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Home
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Crypto Payment</h1>
            <p className="text-gray-600">Pay with cryptocurrency for {course.name}</p>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Payment Form */}
          <div className="lg:col-span-2 space-y-6">
            {/* Course Summary */}
            <Card>
              <CardHeader>
                <CardTitle>Course Details</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex justify-between items-center">
                  <div>
                    <h3 className="font-semibold text-gray-900">{course.name}</h3>
                    <p className="text-sm text-gray-600 capitalize">{course.level} Level</p>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-bold text-primary">${course.price}</p>
                    <p className="text-sm text-gray-600">USD</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Currency Selection */}
            <Card>
              <CardHeader>
                <CardTitle>Select Cryptocurrency</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="currency">Choose Currency</Label>
                  <Select value={selectedCurrency} onValueChange={setSelectedCurrency}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a cryptocurrency" />
                    </SelectTrigger>
                    <SelectContent>
                      {cryptoSettings.map((setting: any) => (
                        <SelectItem key={setting.id} value={setting.currency}>
                          {setting.currency} ({setting.networkName})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {selectedCurrency && (
                  <div className="space-y-4">
                    <div>
                      <Label>Payment Address</Label>
                      <div className="flex items-center space-x-2">
                        <Input
                          value={cryptoSettings.find((s: any) => s.currency === selectedCurrency)?.walletAddress || ""}
                          readOnly
                          className="font-mono text-sm"
                        />
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => copyToClipboard(
                            cryptoSettings.find((s: any) => s.currency === selectedCurrency)?.walletAddress || ""
                          )}
                        >
                          <Copy className="w-4 h-4" />
                        </Button>
                      </div>
                      <p className="text-sm text-gray-600 mt-1">
                        Send exactly ${course.price} worth of {selectedCurrency} to this address
                      </p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Payment Proof */}
            <Card>
              <CardHeader>
                <CardTitle>Payment Proof</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="transactionId">Transaction ID *</Label>
                  <Input
                    id="transactionId"
                    value={transactionId}
                    onChange={(e) => setTransactionId(e.target.value)}
                    placeholder="Enter your transaction hash/ID"
                    className="font-mono"
                  />
                </div>

                <div>
                  <Label htmlFor="amount">Amount Sent *</Label>
                  <Input
                    id="amount"
                    type="number"
                    step="0.00000001"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="Enter the amount you sent"
                  />
                </div>

                <div>
                  <Label htmlFor="proofUrl">Proof Image URL (Optional)</Label>
                  <Input
                    id="proofUrl"
                    value={proofImageUrl}
                    onChange={(e) => setProofImageUrl(e.target.value)}
                    placeholder="https://..."
                  />
                  <p className="text-sm text-gray-600 mt-1">
                    Upload a screenshot to an image hosting service and paste the URL here
                  </p>
                </div>

                <Button
                  onClick={handleSubmitPayment}
                  disabled={createPaymentRequestMutation.isPending || !selectedCurrency || !transactionId || !amount}
                  className="w-full bg-primary hover:bg-blue-700"
                  size="lg"
                >
                  {createPaymentRequestMutation.isPending ? "Submitting..." : "Submit Payment Request"}
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Payment Status */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle>Payment History</CardTitle>
              </CardHeader>
              <CardContent>
                {paymentRequests.length > 0 ? (
                  <div className="space-y-4">
                    {paymentRequests.map((request: any) => (
                      <div key={request.id} className="border rounded-lg p-4">
                        <div className="flex items-center justify-between mb-2">
                          <Badge className={getStatusColor(request.status)}>
                            {getStatusIcon(request.status)}
                            <span className="ml-1 capitalize">{request.status}</span>
                          </Badge>
                          <span className="text-sm text-gray-600">
                            {new Date(request.createdAt).toLocaleDateString()}
                          </span>
                        </div>
                        <div className="space-y-1 text-sm">
                          <p><strong>Currency:</strong> {request.cryptoCurrency}</p>
                          <p><strong>Amount:</strong> {request.amount}</p>
                          <p><strong>USD Value:</strong> ${request.usdAmount}</p>
                          {request.adminNotes && (
                            <p><strong>Admin Notes:</strong> {request.adminNotes}</p>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center text-gray-500 py-8">
                    <p>No payment requests yet</p>
                    <p className="text-sm">Submit your first crypto payment above</p>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card className="mt-6">
              <CardHeader>
                <CardTitle className="text-lg">Payment Instructions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm text-gray-600">
                <div className="space-y-2">
                  <p><strong>1.</strong> Select your preferred cryptocurrency</p>
                  <p><strong>2.</strong> Copy the payment address</p>
                  <p><strong>3.</strong> Send the exact USD amount in crypto</p>
                  <p><strong>4.</strong> Enter your transaction ID</p>
                  <p><strong>5.</strong> Submit for admin verification</p>
                </div>
                <Separator />
                <div className="bg-amber-50 p-3 rounded-lg">
                  <p className="text-amber-800 font-medium">Important:</p>
                  <p className="text-amber-700">
                    Payments are verified manually by our admin team. This process typically takes 1-24 hours.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}