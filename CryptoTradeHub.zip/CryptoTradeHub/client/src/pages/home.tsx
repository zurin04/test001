import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Download, BookOpen, Trophy, Clock } from "lucide-react";
import { Link } from "wouter";
import CertificateModal from "@/components/certificate-modal";
import { useState } from "react";

interface Enrollment {
  id: number;
  courseId: number;
  enrolledAt: string;
  completedAt: string | null;
  course: {
    id: number;
    name: string;
    level: string;
    price: string;
  };
  progress: {
    progressPercentage: number;
  };
}

interface Certificate {
  id: number;
  certificateId: string;
  finalScore: number;
  issuedAt: string;
  course: {
    name: string;
    level: string;
  };
}

export default function Home() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [selectedCertificate, setSelectedCertificate] = useState<Certificate | null>(null);

  const { data: enrollments = [] } = useQuery({
    queryKey: ["/api/enrollments"],
  });

  const { data: certificates = [] } = useQuery({
    queryKey: ["/api/certificates"],
  });

  const { data: allCourses = [] } = useQuery({
    queryKey: ["/api/courses"],
  });

  const getStatusBadge = (enrollment: Enrollment) => {
    if (enrollment.completedAt) {
      return <Badge className="bg-emerald-500">Completed</Badge>;
    } else if (enrollment.progress.progressPercentage > 0) {
      return <Badge variant="outline" className="border-primary text-primary">In Progress</Badge>;
    } else {
      return <Badge variant="secondary">Not Started</Badge>;
    }
  };

  const getProgressColor = (progress: number) => {
    if (progress === 100) return "bg-emerald-500";
    if (progress > 0) return "bg-primary";
    return "bg-gray-400";
  };

  const availableCourses = allCourses.filter((course: any) => 
    !enrollments.some((enrollment: Enrollment) => enrollment.courseId === course.id)
  );

  return (
    <div className="min-h-screen crypto-bg py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold font-poppins text-foreground mb-2">
            Welcome back, {user?.firstName || 'Student'}!
          </h1>
          <p className="text-muted-foreground font-roboto">Continue your learning journey</p>
        </div>

        {/* Enrolled Courses */}
        {enrollments.length > 0 && (
          <div className="mb-12">
            <h2 className="text-2xl font-bold font-poppins text-foreground mb-6">My Courses</h2>
            <div className="grid lg:grid-cols-3 gap-8">
              {enrollments.map((enrollment: Enrollment) => (
                <Card key={enrollment.id} className="course-card">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-lg font-semibold text-gray-900">
                        {enrollment.course.name}
                      </h3>
                      {getStatusBadge(enrollment)}
                    </div>
                    
                    <div className="mb-4">
                      <div className="flex justify-between text-sm text-gray-600 mb-2">
                        <span>Progress</span>
                        <span>{enrollment.progress.progressPercentage}%</span>
                      </div>
                      <Progress 
                        value={enrollment.progress.progressPercentage} 
                        className="h-2"
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      {enrollment.completedAt ? (
                        <>
                          <span className="text-sm text-gray-600">Certificate earned</span>
                          <Button
                            size="sm"
                            className="bg-emerald-500 hover:bg-emerald-600"
                            onClick={() => {
                              const cert = certificates.find((c: Certificate) => 
                                c.course.name === enrollment.course.name
                              );
                              if (cert) setSelectedCertificate(cert);
                            }}
                          >
                            <Download className="w-4 h-4 mr-2" />
                            Download
                          </Button>
                        </>
                      ) : (
                        <>
                          <span className="text-sm text-gray-600">
                            {enrollment.progress.progressPercentage === 0 ? 'Ready to start' : 'Continue learning'}
                          </span>
                          <Link href={`/course/${enrollment.courseId}`}>
                            <Button size="sm" className="bg-primary hover:bg-blue-700">
                              {enrollment.progress.progressPercentage === 0 ? 'Start' : 'Continue'}
                            </Button>
                          </Link>
                        </>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Available Courses */}
        {availableCourses.length > 0 && (
          <div className="mb-12">
            <h2 className="text-2xl font-bold font-poppins text-foreground mb-6">Available Courses</h2>
            <div className="grid lg:grid-cols-3 gap-8">
              {availableCourses.map((course: any) => (
                <Card key={course.id} className="course-card">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-lg font-semibold font-poppins text-foreground">
                        {course.name}
                      </h3>
                      {course.price === '0.00' ? (
                        <Badge className="level-basic">FREE</Badge>
                      ) : (
                        <Badge variant="outline" className="border-primary text-primary">${course.price}</Badge>
                      )}
                    </div>
                    
                    <p className="text-muted-foreground mb-6 font-roboto">{course.description}</p>
                    
                    <div className="space-y-3">
                      <Link href={`/course-content/${course.id}`}>
                        <Button size="sm" variant="outline" className="w-full">
                          View Course Details
                        </Button>
                      </Link>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground capitalize font-roboto">
                          {course.level} Level
                        </span>
                        {course.price === '0.00' ? (
                          <Button 
                            size="sm" 
                            className="btn-primary"
                            onClick={async () => {
                              try {
                                const response = await fetch('/api/enroll', {
                                  method: 'POST',
                                  headers: {
                                    'Content-Type': 'application/json',
                                  },
                                  body: JSON.stringify({
                                    courseId: course.id,
                                    paymentIntentId: null,
                                  }),
                                });

                                if (response.ok) {
                                  toast({
                                    title: "Success",
                                    description: "Successfully enrolled in the course!",
                                  });
                                  window.location.reload();
                                } else {
                                  const error = await response.json();
                                  toast({
                                    title: "Error",
                                    description: error.message || "Failed to enroll",
                                    variant: "destructive",
                                  });
                                }
                              } catch (error) {
                                toast({
                                  title: "Error",
                                  description: "Network error occurred",
                                  variant: "destructive",
                                });
                              }
                            }}
                          >
                            Enroll Free
                          </Button>
                        ) : (
                          <div className="flex flex-col space-y-2">
                            <Link href={`/checkout/${course.id}`}>
                              <Button size="sm" className="btn-primary w-full">
                                Card ${course.price}
                              </Button>
                            </Link>
                            <Link href={`/crypto-payment/${course.id}`}>
                              <Button size="sm" className="btn-crypto w-full">
                                Crypto ${course.price}
                              </Button>
                            </Link>
                          </div>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Recent Activity */}
        <div className="mb-12">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Clock className="w-5 h-5 mr-2" />
                Recent Activity
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {certificates.slice(0, 3).map((cert: Certificate) => (
                  <div key={cert.id} className="flex items-center space-x-4">
                    <div className="w-10 h-10 bg-emerald-500 rounded-full flex items-center justify-center">
                      <Trophy className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <p className="font-semibold text-gray-900">
                        Completed {cert.course.name}
                      </p>
                      <p className="text-sm text-gray-600">
                        Earned certificate - Score: {cert.finalScore}%
                      </p>
                    </div>
                  </div>
                ))}
                
                {enrollments.filter((e: Enrollment) => e.progress.progressPercentage > 0 && !e.completedAt)
                  .slice(0, 2).map((enrollment: Enrollment) => (
                  <div key={enrollment.id} className="flex items-center space-x-4">
                    <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                      <BookOpen className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <p className="font-semibold text-gray-900">
                        Continued {enrollment.course.name}
                      </p>
                      <p className="text-sm text-gray-600">
                        Progress: {enrollment.progress.progressPercentage}%
                      </p>
                    </div>
                  </div>
                ))}
                
                {certificates.length === 0 && enrollments.length === 0 && (
                  <p className="text-gray-500 text-center py-8">
                    No recent activity. Start a course to see your progress here!
                  </p>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Certificates Modal */}
        {selectedCertificate && (
          <CertificateModal
            certificate={selectedCertificate}
            user={user}
            onClose={() => setSelectedCertificate(null)}
          />
        )}
      </div>
    </div>
  );
}
