import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { CheckCircle, Sprout, TrendingUp, Crown, Star } from "lucide-react";
import { Link } from "wouter";

interface Course {
  id: number;
  name: string;
  description: string;
  level: string;
  price: string;
}

export default function Landing() {
  const { data: courses = [] } = useQuery({
    queryKey: ["/api/courses"],
  });

  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  const getCourseIcon = (level: string) => {
    switch (level) {
      case "basic":
        return <Sprout className="w-8 h-8 text-white" />;
      case "intermediate":
        return <TrendingUp className="w-8 h-8 text-white" />;
      case "advanced":
        return <Crown className="w-8 h-8 text-white" />;
      default:
        return <Star className="w-8 h-8 text-white" />;
    }
  };

  const getCourseColor = (level: string) => {
    switch (level) {
      case "basic":
        return "bg-emerald-500";
      case "intermediate":
        return "bg-blue-500";
      case "advanced":
        return "bg-amber-500";
      default:
        return "bg-gray-500";
    }
  };

  const getCourseFeatures = (level: string) => {
    switch (level) {
      case "basic":
        return [
          "Introduction to Cryptocurrency",
          "Basic Trading Concepts", 
          "Wallet Management",
          "5 Lessons + Quizzes",
          "Certificate of Completion"
        ];
      case "intermediate":
        return [
          "Technical Analysis",
          "Trading Strategies",
          "Risk Management", 
          "10 Lessons + Advanced Quizzes",
          "Professional Certificate"
        ];
      case "advanced":
        return [
          "Advanced Trading Strategies",
          "Portfolio Management",
          "DeFi & Future Markets",
          "15 Lessons + Expert Quizzes", 
          "Master Trader Certificate"
        ];
      default:
        return [];
    }
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="hero-gradient text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center animate-fade-in">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Master Cryptocurrency Trading
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-blue-100">
              Learn from beginner to advanced with our comprehensive trading courses
            </p>
            <Button 
              onClick={handleLogin}
              size="lg" 
              className="bg-accent hover:bg-amber-500 text-black px-8 py-4 text-lg font-semibold transform hover:scale-105 transition-all"
            >
              Start Learning Today
            </Button>
          </div>
        </div>
      </section>

      {/* Course Overview */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Choose Your Learning Path
            </h2>
            <p className="text-xl text-gray-600">
              Structured courses designed to take you from beginner to expert trader
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {courses.map((course: Course, index: number) => (
              <Card 
                key={course.id} 
                className={`course-card relative ${
                  course.level === 'intermediate' ? 'border-2 border-primary transform scale-105' : ''
                }`}
              >
                {course.level === 'intermediate' && (
                  <div className="popular-badge">POPULAR</div>
                )}
                <CardContent className="p-8">
                  <div className="text-center mb-6">
                    <div className={`w-16 h-16 ${getCourseColor(course.level)} rounded-full flex items-center justify-center mx-auto mb-4`}>
                      {getCourseIcon(course.level)}
                    </div>
                    <h3 className="text-2xl font-bold text-gray-900 mb-2">
                      {course.name}
                    </h3>
                    <div className={`text-3xl font-bold mb-4 ${
                      course.level === 'basic' ? 'text-emerald-500' :
                      course.level === 'intermediate' ? 'text-primary' :
                      'text-amber-500'
                    }`}>
                      {course.price === '0.00' ? 'FREE' : `$${course.price}`}
                    </div>
                    <p className="text-gray-600">{course.description}</p>
                  </div>
                  
                  <ul className="space-y-3 mb-8">
                    {getCourseFeatures(course.level).map((feature, idx) => (
                      <li key={idx} className="flex items-center text-gray-700">
                        <CheckCircle className={`w-5 h-5 mr-3 ${
                          course.level === 'basic' ? 'text-emerald-500' :
                          course.level === 'intermediate' ? 'text-primary' :
                          'text-amber-500'
                        }`} />
                        {feature}
                      </li>
                    ))}
                  </ul>
                  
                  <div className="space-y-3">
                    <Link href={`/course-content/${course.id}`}>
                      <Button variant="outline" className="w-full py-3">
                        View Course Details
                      </Button>
                    </Link>
                    <Button 
                      onClick={handleLogin}
                      className={`w-full py-3 font-semibold transition ${
                        course.level === 'basic' 
                          ? 'bg-emerald-500 hover:bg-emerald-600 text-white' :
                        course.level === 'intermediate' 
                          ? 'bg-primary hover:bg-blue-700 text-white' :
                          'bg-amber-500 hover:bg-amber-600 text-black'
                      }`}
                    >
                      {course.price === '0.00' ? 'Start Free Course' : 'Enroll Now'}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Bundle Offer */}
          <div className="mt-12 bundle-gradient rounded-xl p-8 text-white text-center">
            <h3 className="text-2xl font-bold mb-4">Complete Bundle Package</h3>
            <p className="text-blue-100 mb-6">Get access to all courses and save $10</p>
            <div className="flex justify-center items-center space-x-4 mb-6">
              <span className="text-2xl line-through text-blue-200">$150</span>
              <span className="text-4xl font-bold text-accent">$140</span>
              <Badge variant="destructive" className="bg-red-500">
                Save $10
              </Badge>
            </div>
            <Button 
              onClick={handleLogin}
              className="bg-accent hover:bg-amber-500 text-black px-8 py-3 font-semibold transition"
            >
              Get Complete Bundle
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="crypto-dark text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-xl font-bold mb-4">CryptoTrade Academy</h3>
              <p className="text-gray-300 mb-4">
                Master cryptocurrency trading with our comprehensive courses designed for all skill levels.
              </p>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Courses</h4>
              <ul className="space-y-2 text-gray-300">
                <li>Basic Course</li>
                <li>Intermediate Course</li>
                <li>Advanced Course</li>
                <li>Bundle Package</li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-gray-300">
                <li>Help Center</li>
                <li>Contact Us</li>
                <li>Terms of Service</li>
                <li>Privacy Policy</li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Newsletter</h4>
              <p className="text-gray-300 mb-4">Get the latest updates and trading tips</p>
              <div className="flex">
                <input 
                  type="email" 
                  placeholder="Enter your email" 
                  className="flex-1 px-4 py-2 rounded-l-lg border-0 text-gray-900 focus:ring-2 focus:ring-primary"
                />
                <Button className="bg-primary hover:bg-blue-700 px-4 py-2 rounded-r-lg rounded-l-none">
                  Subscribe
                </Button>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-8 pt-8 text-center text-gray-300">
            <p>&copy; 2023 CryptoTrade Academy. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
