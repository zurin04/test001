import { useParams, useLocation } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { Trophy, Clock, ArrowLeft, ArrowRight } from "lucide-react";

interface Question {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
}

interface Quiz {
  id: number;
  title: string;
  description: string;
  questions: Question[];
  passingScore: number;
  timeLimit: number;
  isFinalExam: boolean;
  courseId?: number;
}

export default function Quiz() {
  const { id } = useParams();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [timeLeft, setTimeLeft] = useState(0);
  const [quizStarted, setQuizStarted] = useState(false);
  const [quizSubmitted, setQuizSubmitted] = useState(false);
  const [results, setResults] = useState<any>(null);

  // Mock quiz data - in real app this would come from API
  const mockQuiz: Quiz = {
    id: parseInt(id || "1"),
    title: "Technical Indicators Quiz",
    description: "Test your knowledge of moving averages and technical indicators",
    questions: [
      {
        id: "q1",
        question: "What is the main purpose of a Simple Moving Average (SMA)?",
        options: [
          "To predict exact future prices",
          "To smooth out price fluctuations and identify trends",
          "To calculate trading volume",
          "To determine market capitalization"
        ],
        correctAnswer: 1
      },
      {
        id: "q2",
        question: "Which moving average gives more weight to recent prices?",
        options: [
          "Simple Moving Average (SMA)",
          "Weighted Moving Average (WMA)",
          "Exponential Moving Average (EMA)", 
          "All moving averages weight prices equally"
        ],
        correctAnswer: 2
      },
      {
        id: "q3",
        question: "When the price is above the moving average, it typically indicates:",
        options: [
          "A downtrend",
          "An uptrend",
          "Sideways movement",
          "High volatility"
        ],
        correctAnswer: 1
      },
      {
        id: "q4",
        question: "What is a common signal for entry/exit points in moving average strategies?",
        options: [
          "Price touching the moving average",
          "Moving average changing color",
          "Crossover of different moving averages",
          "Moving average reaching a specific number"
        ],
        correctAnswer: 2
      },
      {
        id: "q5",
        question: "Which time period is commonly used for short-term trading with moving averages?",
        options: [
          "200-day moving average",
          "100-day moving average",
          "50-day moving average",
          "20-day moving average"
        ],
        correctAnswer: 3
      }
    ],
    passingScore: 70,
    timeLimit: 10, // 10 minutes
    isFinalExam: false,
    courseId: 1
  };

  const submitQuizMutation = useMutation({
    mutationFn: async (quizData: any) => {
      await apiRequest("POST", "/api/quiz-attempt", quizData);
    },
    onSuccess: (data) => {
      setResults(data);
      setQuizSubmitted(true);
      queryClient.invalidateQueries({ queryKey: ["/api/enrollments"] });
      queryClient.invalidateQueries({ queryKey: ["/api/certificates"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized", 
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to submit quiz",
        variant: "destructive",
      });
    },
  });

  useEffect(() => {
    if (quizStarted && timeLeft > 0) {
      const timer = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            handleSubmitQuiz();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);

      return () => clearInterval(timer);
    }
  }, [quizStarted, timeLeft]);

  const startQuiz = () => {
    setQuizStarted(true);
    setTimeLeft(mockQuiz.timeLimit * 60); // Convert minutes to seconds
  };

  const handleAnswerChange = (questionId: string, answerIndex: number) => {
    setAnswers(prev => ({
      ...prev,
      [questionId]: answerIndex
    }));
  };

  const handleSubmitQuiz = () => {
    // Calculate score
    let correctAnswers = 0;
    mockQuiz.questions.forEach(question => {
      if (answers[question.id] === question.correctAnswer) {
        correctAnswers++;
      }
    });

    const score = Math.round((correctAnswers / mockQuiz.questions.length) * 100);
    const passed = score >= mockQuiz.passingScore;

    const quizData = {
      quizId: mockQuiz.id,
      score,
      answers,
      passed,
      isFinalExam: mockQuiz.isFinalExam,
      courseId: mockQuiz.courseId,
    };

    submitQuizMutation.mutate(quizData);
  };

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const currentQuestion = mockQuiz.questions[currentQuestionIndex];
  const progress = ((currentQuestionIndex + 1) / mockQuiz.questions.length) * 100;

  if (quizSubmitted && results) {
    return (
      <div className="min-h-screen crypto-light py-12">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <Card>
            <CardContent className="p-8 text-center">
              <div className="mb-8">
                <div className={`w-20 h-20 ${results.passed ? 'bg-emerald-500' : 'bg-red-500'} rounded-full flex items-center justify-center mx-auto mb-4`}>
                  <Trophy className="w-10 h-10 text-white" />
                </div>
                <h2 className="text-2xl font-bold text-gray-900 mb-2">Quiz Completed!</h2>
                <p className="text-gray-600 mb-4">
                  {results.passed ? 'Congratulations! You passed the quiz.' : 'You did not meet the passing score.'}
                </p>
                <div className={`text-4xl font-bold mb-6 ${results.passed ? 'text-emerald-500' : 'text-red-500'}`}>
                  {results.score}%
                </div>
                <p className="text-gray-600">
                  Passing score: {mockQuiz.passingScore}% - 
                  {results.passed ? ' Well done! You can proceed to the next lesson.' : ' Please review the material and try again.'}
                </p>
              </div>
              
              <div className="flex justify-center space-x-4">
                <Button
                  variant="outline"
                  onClick={() => setLocation(`/course/${mockQuiz.courseId}`)}
                >
                  Back to Course
                </Button>
                {results.passed && (
                  <Button
                    onClick={() => setLocation(`/course/${mockQuiz.courseId}`)}
                    className="bg-primary hover:bg-blue-700"
                  >
                    Continue Learning
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (!quizStarted) {
    return (
      <div className="min-h-screen crypto-light py-12">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <Card>
            <CardHeader>
              <CardTitle className="text-center text-2xl">{mockQuiz.title}</CardTitle>
              <p className="text-center text-gray-600">{mockQuiz.description}</p>
            </CardHeader>
            <CardContent className="p-8">
              <div className="grid md:grid-cols-2 gap-8 mb-8">
                <div className="text-center">
                  <div className="text-3xl font-bold text-primary mb-2">
                    {mockQuiz.questions.length}
                  </div>
                  <p className="text-gray-600">Questions</p>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-primary mb-2">
                    {mockQuiz.timeLimit}
                  </div>
                  <p className="text-gray-600">Minutes</p>
                </div>
              </div>
              
              <div className="text-center mb-8">
                <p className="text-gray-700 mb-4">
                  You need to score at least <strong>{mockQuiz.passingScore}%</strong> to pass this quiz.
                </p>
                <p className="text-sm text-gray-600">
                  Make sure you have a stable internet connection before starting.
                </p>
              </div>
              
              <div className="text-center">
                <Button 
                  onClick={startQuiz}
                  size="lg"
                  className="bg-primary hover:bg-blue-700 px-8 py-3"
                >
                  Start Quiz
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen crypto-light py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <Card>
          <CardHeader>
            <div className="flex justify-between items-center mb-4">
              <CardTitle>{mockQuiz.title}</CardTitle>
              <Badge variant="outline" className="flex items-center">
                <Clock className="w-4 h-4 mr-1" />
                {formatTime(timeLeft)}
              </Badge>
            </div>
            
            {/* Progress Bar */}
            <div className="mb-4">
              <div className="flex justify-between text-sm text-gray-600 mb-2">
                <span>Question {currentQuestionIndex + 1} of {mockQuiz.questions.length}</span>
                <span>Progress: {Math.round(progress)}%</span>
              </div>
              <Progress value={progress} className="h-2" />
            </div>
          </CardHeader>
          
          <CardContent className="p-8">
            <div className="mb-8">
              <h3 className="text-xl font-semibold text-gray-900 mb-6">
                {currentQuestion.question}
              </h3>
              
              <RadioGroup
                value={answers[currentQuestion.id]?.toString() || ""}
                onValueChange={(value) => handleAnswerChange(currentQuestion.id, parseInt(value))}
              >
                <div className="space-y-4">
                  {currentQuestion.options.map((option, index) => (
                    <div key={index} className="flex items-center space-x-2">
                      <RadioGroupItem value={index.toString()} id={`option-${index}`} />
                      <Label 
                        htmlFor={`option-${index}`}
                        className="cursor-pointer flex-1 p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
                      >
                        {option}
                      </Label>
                    </div>
                  ))}
                </div>
              </RadioGroup>
            </div>
            
            <div className="flex justify-between">
              <Button
                variant="outline"
                onClick={() => setCurrentQuestionIndex(prev => Math.max(0, prev - 1))}
                disabled={currentQuestionIndex === 0}
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Previous
              </Button>
              
              {currentQuestionIndex === mockQuiz.questions.length - 1 ? (
                <Button
                  onClick={handleSubmitQuiz}
                  disabled={submitQuizMutation.isPending || Object.keys(answers).length !== mockQuiz.questions.length}
                  className="bg-emerald-500 hover:bg-emerald-600"
                >
                  {submitQuizMutation.isPending ? 'Submitting...' : 'Submit Quiz'}
                </Button>
              ) : (
                <Button
                  onClick={() => setCurrentQuestionIndex(prev => Math.min(mockQuiz.questions.length - 1, prev + 1))}
                  disabled={answers[currentQuestion.id] === undefined}
                  className="bg-primary hover:bg-blue-700"
                >
                  Next Question
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
