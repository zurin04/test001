#!/bin/bash

# CryptoTrade Academy VPS Deployment Script
# This script sets up the complete production environment

set -e

echo "🚀 Starting CryptoTrade Academy deployment..."

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
APP_NAME="cryptotrade-academy"
APP_DIR="/opt/$APP_NAME"
BACKUP_DIR="/opt/backups"
LOG_DIR="/var/log/$APP_NAME"

# Functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if running as root
if [[ $EUID -ne 0 ]]; then
   log_error "This script must be run as root"
   exit 1
fi

# System requirements check
check_requirements() {
    log_info "Checking system requirements..."
    
    # Check if we have at least 1GB RAM
    TOTAL_MEM=$(free -m | awk 'NR==2{printf "%.0f", $2}')
    if [ $TOTAL_MEM -lt 1000 ]; then
        log_warning "Recommended minimum memory is 1GB. Current: ${TOTAL_MEM}MB"
    fi
    
    # Check disk space (minimum 5GB)
    AVAILABLE_DISK=$(df / | awk 'NR==2 {print $4}')
    if [ $AVAILABLE_DISK -lt 5000000 ]; then
        log_warning "Recommended minimum disk space is 5GB"
    fi
    
    log_success "System requirements check completed"
}

# Update system packages
update_system() {
    log_info "Updating system packages..."
    apt update && apt upgrade -y
    
    # Install essential packages
    apt install -y \
        curl \
        wget \
        git \
        unzip \
        htop \
        ufw \
        fail2ban \
        certbot \
        nginx \
        postgresql-client \
        redis-tools
    
    log_success "System packages updated"
}

# Install Docker and Docker Compose
install_docker() {
    log_info "Installing Docker and Docker Compose..."
    
    # Install Docker
    if ! command -v docker &> /dev/null; then
        curl -fsSL https://get.docker.com -o get-docker.sh
        sh get-docker.sh
        usermod -aG docker $USER
        rm get-docker.sh
        log_success "Docker installed"
    else
        log_info "Docker already installed"
    fi
    
    # Install Docker Compose
    if ! command -v docker-compose &> /dev/null; then
        curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
        chmod +x /usr/local/bin/docker-compose
        log_success "Docker Compose installed"
    else
        log_info "Docker Compose already installed"
    fi
    
    # Start Docker service
    systemctl start docker
    systemctl enable docker
}

# Setup firewall
setup_firewall() {
    log_info "Configuring firewall..."
    
    # Reset UFW to defaults
    ufw --force reset
    
    # Default policies
    ufw default deny incoming
    ufw default allow outgoing
    
    # Allow SSH (change port if needed)
    ufw allow 22
    
    # Allow HTTP and HTTPS
    ufw allow 80
    ufw allow 443
    
    # Enable firewall
    ufw --force enable
    
    log_success "Firewall configured"
}

# Setup fail2ban
setup_fail2ban() {
    log_info "Configuring fail2ban..."
    
    cat > /etc/fail2ban/jail.local << EOF
[DEFAULT]
bantime = 3600
findtime = 600
maxretry = 3

[sshd]
enabled = true

[nginx-http-auth]
enabled = true

[nginx-noscript]
enabled = true

[nginx-bad-request]
enabled = true

[nginx-botsearch]
enabled = true
EOF
    
    systemctl restart fail2ban
    systemctl enable fail2ban
    
    log_success "Fail2ban configured"
}

# Create application directories
create_directories() {
    log_info "Creating application directories..."
    
    mkdir -p $APP_DIR
    mkdir -p $BACKUP_DIR
    mkdir -p $LOG_DIR
    mkdir -p /etc/nginx/ssl
    
    log_success "Directories created"
}

# Setup environment file
setup_environment() {
    log_info "Setting up environment configuration..."
    
    if [ ! -f "$APP_DIR/.env" ]; then
        cat > $APP_DIR/.env << EOF
# Production Environment Configuration
NODE_ENV=production

# Database Configuration
DATABASE_URL=postgresql://postgres:your_db_password@postgres:5432/cryptotrade_academy
POSTGRES_USER=postgres
POSTGRES_PASSWORD=your_secure_db_password

# Session Configuration
SESSION_SECRET=your_very_secure_session_secret_here

# Redis Configuration
REDIS_PASSWORD=your_redis_password

# Stripe Configuration (optional)
STRIPE_SECRET_KEY=sk_live_your_stripe_secret_key
VITE_STRIPE_PUBLIC_KEY=pk_live_your_stripe_public_key

# Replit Configuration
REPL_ID=your_repl_id
REPLIT_DOMAINS=your-domain.com

# SSL Configuration
SSL_CERT_PATH=/etc/nginx/ssl/cert.pem
SSL_KEY_PATH=/etc/nginx/ssl/key.pem
EOF
        
        chmod 600 $APP_DIR/.env
        log_warning "Environment file created at $APP_DIR/.env"
        log_warning "Please edit this file with your actual configuration values"
    else
        log_info "Environment file already exists"
    fi
}

# Generate SSL certificates
generate_ssl() {
    log_info "Generating SSL certificates..."
    
    if [ ! -f "/etc/nginx/ssl/cert.pem" ]; then
        # Generate self-signed certificate for testing
        openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
            -keyout /etc/nginx/ssl/key.pem \
            -out /etc/nginx/ssl/cert.pem \
            -subj "/C=US/ST=State/L=City/O=Organization/CN=localhost"
        
        log_success "Self-signed SSL certificate generated"
        log_warning "For production, replace with a proper SSL certificate"
    else
        log_info "SSL certificate already exists"
    fi
}

# Setup monitoring
setup_monitoring() {
    log_info "Setting up monitoring scripts..."
    
    # Create monitoring script
    cat > /usr/local/bin/monitor-app.sh << 'EOF'
#!/bin/bash

APP_NAME="cryptotrade-academy"
LOG_FILE="/var/log/monitor-app.log"

check_container() {
    if ! docker ps | grep -q $APP_NAME; then
        echo "$(date): Container $APP_NAME is not running. Restarting..." >> $LOG_FILE
        cd /opt/cryptotrade-academy && docker-compose up -d
    fi
}

check_disk_space() {
    DISK_USAGE=$(df / | awk 'NR==2 {print $5}' | sed 's/%//')
    if [ $DISK_USAGE -gt 85 ]; then
        echo "$(date): High disk usage: ${DISK_USAGE}%" >> $LOG_FILE
    fi
}

check_memory() {
    MEM_USAGE=$(free | awk 'NR==2{printf "%.0f", $3*100/$2}')
    if [ $MEM_USAGE -gt 85 ]; then
        echo "$(date): High memory usage: ${MEM_USAGE}%" >> $LOG_FILE
    fi
}

check_container
check_disk_space
check_memory
EOF
    
    chmod +x /usr/local/bin/monitor-app.sh
    
    # Add cron job for monitoring
    (crontab -l 2>/dev/null; echo "*/5 * * * * /usr/local/bin/monitor-app.sh") | crontab -
    
    log_success "Monitoring setup completed"
}

# Setup backup script
setup_backup() {
    log_info "Setting up backup system..."
    
    cat > /usr/local/bin/backup-app.sh << 'EOF'
#!/bin/bash

BACKUP_DIR="/opt/backups"
DATE=$(date +%Y%m%d_%H%M%S)
APP_DIR="/opt/cryptotrade-academy"

# Create backup directory
mkdir -p $BACKUP_DIR

# Backup database
docker exec cryptotrade-db pg_dump -U postgres cryptotrade_academy > $BACKUP_DIR/database_$DATE.sql

# Backup application files
tar -czf $BACKUP_DIR/app_$DATE.tar.gz -C /opt cryptotrade-academy

# Keep only last 7 days of backups
find $BACKUP_DIR -name "database_*.sql" -mtime +7 -delete
find $BACKUP_DIR -name "app_*.tar.gz" -mtime +7 -delete

echo "$(date): Backup completed - database_$DATE.sql and app_$DATE.tar.gz"
EOF
    
    chmod +x /usr/local/bin/backup-app.sh
    
    # Add cron job for daily backups
    (crontab -l 2>/dev/null; echo "0 2 * * * /usr/local/bin/backup-app.sh") | crontab -
    
    log_success "Backup system setup completed"
}

# Deploy application
deploy_application() {
    log_info "Deploying application..."
    
    cd $APP_DIR
    
    # Copy application files (assuming they're in current directory)
    if [ -f "docker-compose.yml" ]; then
        log_info "Starting application with Docker Compose..."
        docker-compose down 2>/dev/null || true
        docker-compose pull
        docker-compose up -d --build
        
        # Wait for services to start
        sleep 30
        
        # Check if services are running
        if docker-compose ps | grep -q "Up"; then
            log_success "Application deployed successfully"
        else
            log_error "Application deployment failed"
            docker-compose logs
            exit 1
        fi
    else
        log_error "docker-compose.yml not found in $APP_DIR"
        exit 1
    fi
}

# Setup systemd service
setup_systemd() {
    log_info "Setting up systemd service..."
    
    cat > /etc/systemd/system/cryptotrade-academy.service << EOF
[Unit]
Description=CryptoTrade Academy
Requires=docker.service
After=docker.service

[Service]
Type=oneshot
RemainAfterExit=yes
WorkingDirectory=$APP_DIR
ExecStart=/usr/local/bin/docker-compose up -d
ExecStop=/usr/local/bin/docker-compose down
TimeoutStartSec=0

[Install]
WantedBy=multi-user.target
EOF
    
    systemctl daemon-reload
    systemctl enable cryptotrade-academy.service
    
    log_success "Systemd service configured"
}

# Main deployment function
main() {
    log_info "Starting deployment process..."
    
    check_requirements
    update_system
    install_docker
    setup_firewall
    setup_fail2ban
    create_directories
    setup_environment
    generate_ssl
    setup_monitoring
    setup_backup
    deploy_application
    setup_systemd
    
    log_success "🎉 Deployment completed successfully!"
    echo
    log_info "Next steps:"
    echo "1. Edit $APP_DIR/.env with your actual configuration"
    echo "2. Replace self-signed SSL certificate with a proper one"
    echo "3. Configure your domain DNS to point to this server"
    echo "4. Run: systemctl start cryptotrade-academy"
    echo
    log_info "Useful commands:"
    echo "- View logs: docker-compose -f $APP_DIR/docker-compose.yml logs -f"
    echo "- Restart app: systemctl restart cryptotrade-academy"
    echo "- Check status: systemctl status cryptotrade-academy"
    echo "- Manual backup: /usr/local/bin/backup-app.sh"
}

# Run main function
main "$@"