-- Initialize database for CryptoTrade Academy

-- Create sessions table for express-session
CREATE TABLE IF NOT EXISTS sessions (
  sid varchar NOT NULL COLLATE "default",
  sess json NOT NULL,
  expire timestamp(6) NOT NULL
)
WITH (OIDS=FALSE);

ALTER TABLE sessions ADD CONSTRAINT session_pkey PRIMARY KEY (sid) NOT DEFERRABLE INITIALLY IMMEDIATE;
CREATE INDEX IF NOT EXISTS IDX_session_expire ON sessions (expire);

-- Users table (required for Replit Auth)
CREATE TABLE IF NOT EXISTS users (
  id varchar PRIMARY KEY NOT NULL,
  email varchar UNIQUE,
  first_name varchar,
  last_name varchar,
  profile_image_url varchar,
  stripe_customer_id varchar,
  stripe_subscription_id varchar,
  is_admin boolean DEFAULT false,
  created_at timestamp DEFAULT NOW(),
  updated_at timestamp DEFAULT NOW()
);

-- Courses table
CREATE TABLE IF NOT EXISTS courses (
  id serial PRIMARY KEY,
  name varchar(255) NOT NULL,
  description text,
  level varchar(50) NOT NULL,
  price decimal(10,2) NOT NULL,
  is_active boolean DEFAULT true,
  created_at timestamp DEFAULT NOW()
);

-- Categories table
CREATE TABLE IF NOT EXISTS categories (
  id serial PRIMARY KEY,
  course_id integer REFERENCES courses(id) NOT NULL,
  name varchar(255) NOT NULL,
  description text,
  "order" integer NOT NULL,
  created_at timestamp DEFAULT NOW()
);

-- Lessons table
CREATE TABLE IF NOT EXISTS lessons (
  id serial PRIMARY KEY,
  category_id integer REFERENCES categories(id) NOT NULL,
  title varchar(255) NOT NULL,
  content text,
  "order" integer NOT NULL,
  created_at timestamp DEFAULT NOW()
);

-- Quizzes table
CREATE TABLE IF NOT EXISTS quizzes (
  id serial PRIMARY KEY,
  course_id integer REFERENCES courses(id),
  category_id integer REFERENCES categories(id),
  title varchar(255) NOT NULL,
  description text,
  questions jsonb NOT NULL,
  passing_score integer NOT NULL,
  time_limit integer NOT NULL,
  is_final_exam boolean DEFAULT false,
  created_at timestamp DEFAULT NOW()
);

-- Enrollments table
CREATE TABLE IF NOT EXISTS enrollments (
  id serial PRIMARY KEY,
  user_id varchar REFERENCES users(id) NOT NULL,
  course_id integer REFERENCES courses(id) NOT NULL,
  enrolled_at timestamp DEFAULT NOW(),
  completed_at timestamp,
  payment_intent_id varchar,
  payment_method varchar(50) DEFAULT 'stripe',
  crypto_transaction_id varchar,
  crypto_wallet_address varchar,
  admin_approved_by varchar REFERENCES users(id),
  admin_approval_notes text
);

-- User progress table
CREATE TABLE IF NOT EXISTS user_progress (
  id serial PRIMARY KEY,
  user_id varchar REFERENCES users(id) NOT NULL,
  course_id integer REFERENCES courses(id) NOT NULL,
  lesson_id integer REFERENCES lessons(id),
  progress_percentage integer DEFAULT 0,
  completed_at timestamp,
  created_at timestamp DEFAULT NOW(),
  updated_at timestamp DEFAULT NOW()
);

-- Quiz attempts table
CREATE TABLE IF NOT EXISTS quiz_attempts (
  id serial PRIMARY KEY,
  user_id varchar REFERENCES users(id) NOT NULL,
  quiz_id integer REFERENCES quizzes(id) NOT NULL,
  score integer NOT NULL,
  answers jsonb NOT NULL,
  passed boolean NOT NULL,
  attempted_at timestamp DEFAULT NOW()
);

-- Certificates table
CREATE TABLE IF NOT EXISTS certificates (
  id serial PRIMARY KEY,
  user_id varchar REFERENCES users(id) NOT NULL,
  course_id integer REFERENCES courses(id) NOT NULL,
  certificate_id varchar NOT NULL UNIQUE,
  final_score integer NOT NULL,
  issued_at timestamp DEFAULT NOW()
);

-- Crypto settings table
CREATE TABLE IF NOT EXISTS crypto_settings (
  id serial PRIMARY KEY,
  currency varchar(20) NOT NULL,
  wallet_address varchar NOT NULL,
  network_name varchar(50),
  is_active boolean DEFAULT true,
  created_at timestamp DEFAULT NOW(),
  updated_at timestamp DEFAULT NOW()
);

-- Payment requests table
CREATE TABLE IF NOT EXISTS payment_requests (
  id serial PRIMARY KEY,
  user_id varchar REFERENCES users(id) NOT NULL,
  course_id integer REFERENCES courses(id) NOT NULL,
  crypto_currency varchar(20) NOT NULL,
  wallet_address varchar NOT NULL,
  transaction_id varchar,
  amount decimal(18,8) NOT NULL,
  usd_amount decimal(10,2) NOT NULL,
  status varchar(20) DEFAULT 'pending',
  proof_image_url varchar,
  admin_notes text,
  verified_by varchar REFERENCES users(id),
  verified_at timestamp,
  created_at timestamp DEFAULT NOW()
);

-- Insert sample courses if they don't exist
INSERT INTO courses (name, description, level, price) 
SELECT * FROM (
  VALUES 
    ('Cryptocurrency Basics & Blockchain Fundamentals', 'Master the fundamentals of blockchain technology, Bitcoin, Ethereum, and cryptocurrency markets. Learn wallet security, basic trading concepts, and market analysis. Perfect for absolute beginners with no prior crypto experience.', 'basic', 0.00),
    ('Technical Analysis & Trading Psychology', 'Advanced trading strategies including technical analysis, chart patterns, candlestick analysis, market indicators, risk management, and trading psychology. Learn to read market sentiment and execute profitable trades consistently.', 'intermediate', 50.00),
    ('DeFi Protocols & Advanced Trading Strategies', 'Master decentralized finance, yield farming, liquidity mining, derivatives trading, algorithmic trading strategies, and portfolio management. Learn to navigate complex DeFi protocols and maximize returns through advanced techniques.', 'advanced', 100.00)
) AS v(name, description, level, price)
WHERE NOT EXISTS (SELECT 1 FROM courses);

-- Insert sample crypto settings if they don't exist
INSERT INTO crypto_settings (currency, wallet_address, network_name, is_active) 
SELECT * FROM (
  VALUES 
    ('BTC', '1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa', 'Bitcoin Mainnet', true),
    ('ETH', '0x742d35Cc6861C4532231E5e7B57C37B1839C4565', 'Ethereum Mainnet', true),
    ('USDT', '0x742d35Cc6861C4532231E5e7B57C37B1839C4565', 'Ethereum (ERC-20)', true)
) AS v(currency, wallet_address, network_name, is_active)
WHERE NOT EXISTS (SELECT 1 FROM crypto_settings);

-- Grant necessary permissions
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO postgres;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO postgres;