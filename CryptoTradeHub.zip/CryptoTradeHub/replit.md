# CryptoTrade Academy - Online Learning Platform

## Overview

CryptoTrade Academy is a full-stack online learning platform focused on cryptocurrency trading education. The application provides a complete learning management system with user authentication, payment processing, course management, and certificate generation.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **UI Framework**: Radix UI components with Tailwind CSS for styling
- **Form Handling**: React Hook Form with Zod validation
- **Payment Integration**: Stripe for payment processing

### Backend Architecture
- **Runtime**: Node.js with Express.js server
- **Language**: TypeScript with ES modules
- **Database ORM**: Drizzle ORM for type-safe database operations
- **Authentication**: Custom Replit Auth implementation with OpenID Connect
- **Session Management**: Express sessions with PostgreSQL store

### Build System
- **Development**: Vite with React plugin and TypeScript support
- **Production**: ESBuild for server bundling, Vite for client bundling
- **Module System**: ES modules throughout the stack

## Key Components

### Authentication System
- Replit-based OpenID Connect authentication
- Session-based authentication with PostgreSQL session storage
- User profile management with Stripe customer integration
- Protected routes with authentication middleware

### Database Schema
- **Users**: Profile information and Stripe integration
- **Courses**: Course content with levels (basic, intermediate, advanced)
- **Enrollments**: User course enrollments with progress tracking
- **Lessons**: Course content structure
- **Quizzes**: Assessment system with questions and scoring
- **Certificates**: Achievement tracking and certificate generation

### Payment Processing
- Stripe integration for course purchases
- Customer creation and subscription management
- Secure payment flow with Elements UI
- Enrollment automation after successful payment

### Course Management
- Hierarchical course structure (courses → lessons → quizzes)
- Progress tracking with percentage completion
- Certificate generation upon course completion
- Multiple difficulty levels with appropriate pricing

## Data Flow

1. **User Registration**: Users authenticate via Replit Auth, creating session and user records
2. **Course Discovery**: Public course catalog accessible to all users
3. **Purchase Flow**: Authenticated users can purchase courses via Stripe integration
4. **Learning Path**: Enrolled users access course content, track progress, and complete assessments
5. **Certification**: Upon completion, users receive certificates stored in the database

## External Dependencies

### Core Dependencies
- **Database**: PostgreSQL via Neon serverless driver
- **Authentication**: Replit Auth with OpenID Connect
- **Payments**: Stripe API and React Stripe.js
- **UI Components**: Radix UI component library
- **Styling**: Tailwind CSS with custom design system

### Development Tools
- **TypeScript**: Full type safety across frontend and backend
- **Drizzle Kit**: Database migrations and schema management
- **ESLint/Prettier**: Code quality and formatting
- **Vite**: Fast development server and build tool

## Deployment Strategy

### Development Environment
- Replit-hosted development with auto-reload
- Vite dev server for frontend with HMR
- TSX for server-side TypeScript execution
- PostgreSQL module provisioned automatically

### Production Build
- Client build via Vite to `dist/public`
- Server build via ESBuild to `dist/index.js`
- Static file serving from Express
- Environment-based configuration

### Environment Configuration
- Database URL via environment variables
- Stripe keys for payment processing
- Session secrets for authentication
- Replit-specific deployment configuration

## Recent Changes

✓ Implemented comprehensive crypto wallet payment system with admin management
✓ Added crypto payment request submission and verification workflow  
✓ Created admin dashboard for managing wallet addresses and approving payments
✓ Updated database schema with crypto settings and payment request tables
✓ Enhanced course enrollment to support multiple payment methods (Stripe, crypto, admin)
✓ Added payment method selection on course cards (Card/Crypto buttons)
✓ Fixed all critical application errors and database connection issues
✓ Enhanced UI with modern design, gradients, animations, and professional styling
✓ Improved landing page with hero section, floating elements, and better visual hierarchy
✓ Upgraded navbar with glass morphism effect and enhanced user dropdown
✓ Added responsive course cards with level badges and hover animations
✓ Implemented complete course management system for admins
✓ Added course CRUD operations (create, read, update, delete)
✓ Created comprehensive VPS deployment system with production-ready configuration
✓ Added Docker containerization with multi-service architecture
✓ Implemented nginx reverse proxy with SSL, compression, and security headers
✓ Created automated deployment script with monitoring, backups, and systemd service
✓ Added production build pipeline and environment configuration
✓ Configured PostgreSQL and Redis for production scalability
✓ Implemented comprehensive security measures (firewall, fail2ban, rate limiting)

## Changelog

```
Changelog:
- June 25, 2025. Initial setup
- June 25, 2025. Added crypto wallet payment system with admin management
- June 25, 2025. Enhanced UI and added complete course management system
- June 25, 2025. Created comprehensive VPS deployment with production architecture
- June 25, 2025. Added Docker containerization, nginx proxy, and security hardening
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```