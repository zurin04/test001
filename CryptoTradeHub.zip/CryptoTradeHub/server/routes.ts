import type { Express, RequestHandler } from "express";
import { createServer, type Server } from "http";
import Stripe from "stripe";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { z } from "zod";
import { insertEnrollmentSchema, insertQuizAttemptSchema } from "@shared/schema";

let stripe: Stripe | null = null;

if (process.env.STRIPE_SECRET_KEY) {
  stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Health check endpoint for load balancer/monitoring
  app.get('/api/health', (req, res) => {
    res.status(200).json({ 
      status: 'healthy', 
      timestamp: new Date().toISOString(),
      uptime: process.uptime()
    });
  });
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Course routes
  app.get('/api/courses', async (req, res) => {
    try {
      const courses = await storage.getAllCourses();
      res.json(courses);
    } catch (error) {
      console.error("Error fetching courses:", error);
      res.status(500).json({ message: "Failed to fetch courses" });
    }
  });

  app.get('/api/courses/:id', isAuthenticated, async (req: any, res) => {
    try {
      const courseId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      
      // Check if user is enrolled
      const isEnrolled = await storage.isUserEnrolled(userId, courseId);
      if (!isEnrolled) {
        return res.status(403).json({ message: "Not enrolled in this course" });
      }

      const courseWithProgress = await storage.getUserProgress(userId, courseId);
      res.json(courseWithProgress);
    } catch (error) {
      console.error("Error fetching course:", error);
      res.status(500).json({ message: "Failed to fetch course" });
    }
  });

  // Enrollment routes
  app.get('/api/enrollments', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const enrollments = await storage.getUserEnrollments(userId);
      
      // Get course details for each enrollment
      const enrollmentsWithCourses = await Promise.all(
        enrollments.map(async (enrollment) => {
          const course = await storage.getCourse(enrollment.courseId);
          const progress = await storage.getUserProgress(userId, enrollment.courseId);
          return {
            ...enrollment,
            course,
            progress: progress?.progress || { progressPercentage: 0 },
          };
        })
      );
      
      res.json(enrollmentsWithCourses);
    } catch (error) {
      console.error("Error fetching enrollments:", error);
      res.status(500).json({ message: "Failed to fetch enrollments" });
    }
  });

  app.post('/api/enroll', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { courseId, paymentIntentId } = req.body;
      
      // Check if already enrolled
      const isEnrolled = await storage.isUserEnrolled(userId, courseId);
      if (isEnrolled) {
        return res.status(400).json({ message: "Already enrolled in this course" });
      }

      const enrollment = await storage.enrollUser({
        userId,
        courseId,
        paymentIntentId,
      });
      
      res.json(enrollment);
    } catch (error) {
      console.error("Error enrolling user:", error);
      res.status(500).json({ message: "Failed to enroll user" });
    }
  });

  // Progress routes
  app.post('/api/progress', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { lessonId, completed } = req.body;
      
      const progress = await storage.updateUserProgress({
        userId,
        lessonId,
        completed,
      });
      
      res.json(progress);
    } catch (error) {
      console.error("Error updating progress:", error);
      res.status(500).json({ message: "Failed to update progress" });
    }
  });

  // Quiz routes
  app.post('/api/quiz-attempt', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const attemptData = insertQuizAttemptSchema.parse({
        ...req.body,
        userId,
      });
      
      const attempt = await storage.submitQuizAttempt(attemptData);
      
      // If it's a final exam and user passed, issue certificate
      if (attempt.passed && req.body.isFinalExam) {
        const certificateId = `CTA-${Date.now()}-${userId.slice(-4)}`;
        await storage.issueCertificate({
          userId,
          courseId: req.body.courseId,
          certificateId,
          finalScore: attempt.score,
        });
      }
      
      res.json(attempt);
    } catch (error) {
      console.error("Error submitting quiz attempt:", error);
      res.status(500).json({ message: "Failed to submit quiz attempt" });
    }
  });

  // Certificate routes
  app.get('/api/certificates', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const certificates = await storage.getUserCertificates(userId);
      
      // Get course details for each certificate
      const certificatesWithCourses = await Promise.all(
        certificates.map(async (cert) => {
          const course = await storage.getCourse(cert.courseId);
          return {
            ...cert,
            course,
          };
        })
      );
      
      res.json(certificatesWithCourses);
    } catch (error) {
      console.error("Error fetching certificates:", error);
      res.status(500).json({ message: "Failed to fetch certificates" });
    }
  });

  app.get('/api/certificates/:certificateId', async (req, res) => {
    try {
      const { certificateId } = req.params;
      const certificate = await storage.getCertificate(certificateId);
      
      if (!certificate) {
        return res.status(404).json({ message: "Certificate not found" });
      }
      
      const user = await storage.getUser(certificate.userId);
      const course = await storage.getCourse(certificate.courseId);
      
      res.json({
        ...certificate,
        user,
        course,
      });
    } catch (error) {
      console.error("Error fetching certificate:", error);
      res.status(500).json({ message: "Failed to fetch certificate" });
    }
  });

  // Stripe payment routes
  app.post("/api/create-payment-intent", isAuthenticated, async (req: any, res) => {
    try {
      if (!stripe) {
        return res.status(500).json({ message: "Payment system not configured" });
      }
      
      const { amount, courseId } = req.body;
      const userId = req.user.claims.sub;
      
      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(amount * 100), // Convert to cents
        currency: "usd",
        metadata: {
          userId,
          courseId: courseId.toString(),
        },
      });
      
      res.json({ clientSecret: paymentIntent.client_secret });
    } catch (error: any) {
      res.status(500).json({ message: "Error creating payment intent: " + error.message });
    }
  });

  // Webhook to handle successful payments
  app.post('/api/webhook', async (req, res) => {
    if (!stripe) {
      return res.status(500).json({ message: "Payment system not configured" });
    }

    const sig = req.headers['stripe-signature'];
    let event;

    try {
      event = stripe.webhooks.constructEvent(req.body, sig!, process.env.STRIPE_WEBHOOK_SECRET!);
    } catch (err: any) {
      console.log(`Webhook signature verification failed.`, err.message);
      return res.status(400).send(`Webhook Error: ${err.message}`);
    }

    if (event.type === 'payment_intent.succeeded') {
      const paymentIntent = event.data.object;
      const { userId, courseId } = paymentIntent.metadata;
      
      // Auto-enroll user in course
      try {
        await storage.enrollUser({
          userId,
          courseId: parseInt(courseId),
          paymentIntentId: paymentIntent.id,
        });
      } catch (error) {
        console.error("Error auto-enrolling user:", error);
      }
    }

    res.json({ received: true });
  });

  // Admin middleware
  const isAdmin: RequestHandler = async (req, res, next) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const user = await storage.getUser((req.user as any).claims.sub);
    if (!user?.isAdmin) {
      return res.status(403).json({ message: "Admin access required" });
    }

    next();
  };

  // Crypto payment routes
  app.get('/api/crypto-settings', async (req, res) => {
    try {
      const settings = await storage.getCryptoSettings();
      res.json(settings);
    } catch (error) {
      console.error("Error fetching crypto settings:", error);
      res.status(500).json({ message: "Failed to fetch crypto settings" });
    }
  });

  app.post('/api/payment-request', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { courseId, cryptoCurrency, walletAddress, transactionId, amount, usdAmount, proofImageUrl } = req.body;

      const paymentRequest = await storage.createPaymentRequest({
        userId,
        courseId,
        cryptoCurrency,
        walletAddress,
        transactionId,
        amount,
        usdAmount,
        proofImageUrl,
      });

      res.json(paymentRequest);
    } catch (error) {
      console.error("Error creating payment request:", error);
      res.status(500).json({ message: "Failed to create payment request" });
    }
  });

  app.get('/api/payment-requests', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const requests = await storage.getUserPaymentRequests(userId);
      res.json(requests);
    } catch (error) {
      console.error("Error fetching payment requests:", error);
      res.status(500).json({ message: "Failed to fetch payment requests" });
    }
  });

  // Admin routes
  app.get('/api/admin/users', [isAuthenticated, isAdmin], async (req: any, res: any) => {
    try {
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  app.get('/api/admin/enrollments', [isAuthenticated, isAdmin], async (req: any, res: any) => {
    try {
      const enrollments = await storage.getAllEnrollments();
      
      // Get user and course details for each enrollment
      const enrollmentsWithDetails = await Promise.all(
        enrollments.map(async (enrollment) => {
          const user = await storage.getUser(enrollment.userId);
          const course = await storage.getCourse(enrollment.courseId);
          return {
            ...enrollment,
            user,
            course,
          };
        })
      );
      
      res.json(enrollmentsWithDetails);
    } catch (error) {
      console.error("Error fetching enrollments:", error);
      res.status(500).json({ message: "Failed to fetch enrollments" });
    }
  });

  app.get('/api/admin/payment-requests', [isAuthenticated, isAdmin], async (req: any, res: any) => {
    try {
      const status = req.query.status as string;
      const requests = await storage.getPaymentRequests(status);
      
      // Get user and course details for each request
      const requestsWithDetails = await Promise.all(
        requests.map(async (request) => {
          const user = await storage.getUser(request.userId);
          const course = await storage.getCourse(request.courseId);
          return {
            ...request,
            user,
            course,
          };
        })
      );
      
      res.json(requestsWithDetails);
    } catch (error) {
      console.error("Error fetching payment requests:", error);
      res.status(500).json({ message: "Failed to fetch payment requests" });
    }
  });

  app.post('/api/admin/enroll-user', [isAuthenticated, isAdmin], async (req: any, res: any) => {
    try {
      const adminId = req.user.claims.sub;
      const { userId, courseId, notes } = req.body;

      // Check if user is already enrolled
      const isEnrolled = await storage.isUserEnrolled(userId, courseId);
      if (isEnrolled) {
        return res.status(400).json({ message: "User is already enrolled in this course" });
      }

      const enrollment = await storage.adminEnrollUser(userId, courseId, adminId, notes);
      res.json(enrollment);
    } catch (error) {
      console.error("Error enrolling user:", error);
      res.status(500).json({ message: "Failed to enroll user" });
    }
  });

  app.post('/api/admin/verify-payment', [isAuthenticated, isAdmin], async (req: any, res: any) => {
    try {
      const adminId = req.user.claims.sub;
      const { requestId, status, notes } = req.body;

      const updatedRequest = await storage.updatePaymentRequestStatus(requestId, status, adminId, notes);
      
      // If payment is verified, enroll user in course
      if (status === 'verified') {
        const isEnrolled = await storage.isUserEnrolled(updatedRequest.userId, updatedRequest.courseId);
        if (!isEnrolled) {
          await storage.enrollUser({
            userId: updatedRequest.userId,
            courseId: updatedRequest.courseId,
            paymentMethod: "crypto",
            cryptoTransactionId: updatedRequest.transactionId,
            cryptoWalletAddress: updatedRequest.walletAddress,
            adminApprovedBy: adminId,
            adminApprovalNotes: notes,
          });
        }
      }

      res.json(updatedRequest);
    } catch (error) {
      console.error("Error verifying payment:", error);
      res.status(500).json({ message: "Failed to verify payment" });
    }
  });

  app.post('/api/admin/crypto-settings', [isAuthenticated, isAdmin], async (req: any, res: any) => {
    try {
      const { currency, walletAddress, networkName } = req.body;
      const setting = await storage.createCryptoSetting({
        currency,
        walletAddress,
        networkName,
      });
      res.json(setting);
    } catch (error) {
      console.error("Error creating crypto setting:", error);
      res.status(500).json({ message: "Failed to create crypto setting" });
    }
  });

  app.put('/api/admin/crypto-settings/:id', [isAuthenticated, isAdmin], async (req: any, res: any) => {
    try {
      const id = parseInt(req.params.id);
      const { currency, walletAddress, networkName, isActive } = req.body;
      const setting = await storage.updateCryptoSetting(id, {
        currency,
        walletAddress,
        networkName,
        isActive,
      });
      res.json(setting);
    } catch (error) {
      console.error("Error updating crypto setting:", error);
      res.status(500).json({ message: "Failed to update crypto setting" });
    }
  });

  app.delete('/api/admin/crypto-settings/:id', [isAuthenticated, isAdmin], async (req: any, res: any) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteCryptoSetting(id);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting crypto setting:", error);
      res.status(500).json({ message: "Failed to delete crypto setting" });
    }
  });

  // Course management routes for admin
  app.post('/api/admin/courses', [isAuthenticated, isAdmin], async (req: any, res: any) => {
    try {
      const { name, description, level, price } = req.body;
      const course = await storage.createCourse({
        name,
        description,
        level,
        price,
      });
      res.json(course);
    } catch (error) {
      console.error("Error creating course:", error);
      res.status(500).json({ message: "Failed to create course" });
    }
  });

  app.put('/api/admin/courses/:id', [isAuthenticated, isAdmin], async (req: any, res: any) => {
    try {
      const id = parseInt(req.params.id);
      const { name, description, level, price } = req.body;
      const course = await storage.updateCourse(id, {
        name,
        description,
        level,
        price,
      });
      res.json(course);
    } catch (error) {
      console.error("Error updating course:", error);
      res.status(500).json({ message: "Failed to update course" });
    }
  });

  app.delete('/api/admin/courses/:id', [isAuthenticated, isAdmin], async (req: any, res: any) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteCourse(id);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting course:", error);
      res.status(500).json({ message: "Failed to delete course" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
