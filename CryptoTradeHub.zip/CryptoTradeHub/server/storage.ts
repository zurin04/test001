import {
  users,
  courses,
  categories,
  lessons,
  quizzes,
  enrollments,
  userProgress,
  quizAttempts,
  certificates,
  cryptoSettings,
  paymentRequests,
  type User,
  type UpsertUser,
  type Course,
  type InsertCourse,
  type Category,
  type Lesson,
  type Quiz,
  type Enrollment,
  type InsertEnrollment,
  type UserProgress,
  type InsertUserProgress,
  type QuizAttempt,
  type InsertQuizAttempt,
  type Certificate,
  type InsertCertificate,
  type CryptoSetting,
  type InsertCryptoSetting,
  type PaymentRequest,
  type InsertPaymentRequest,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc } from "drizzle-orm";

export interface IStorage {
  // User operations (required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  updateUserStripeInfo(userId: string, stripeCustomerId: string, stripeSubscriptionId?: string): Promise<User>;
  updateUserAdminStatus(userId: string, isAdmin: boolean): Promise<User>;
  getAllUsers(): Promise<User[]>;
  
  // Course operations
  getAllCourses(): Promise<Course[]>;
  getCourse(id: number): Promise<Course | undefined>;
  getCourseWithContent(id: number): Promise<any>;
  createCourse(course: InsertCourse): Promise<Course>;
  updateCourse(id: number, course: Partial<InsertCourse>): Promise<Course>;
  deleteCourse(id: number): Promise<void>;
  
  // Enrollment operations
  enrollUser(enrollment: InsertEnrollment): Promise<Enrollment>;
  getUserEnrollments(userId: string): Promise<Enrollment[]>;
  isUserEnrolled(userId: string, courseId: number): Promise<boolean>;
  getAllEnrollments(): Promise<Enrollment[]>;
  adminEnrollUser(userId: string, courseId: number, adminId: string, notes?: string): Promise<Enrollment>;
  
  // Progress operations
  getUserProgress(userId: string, courseId: number): Promise<any>;
  updateUserProgress(progress: InsertUserProgress): Promise<UserProgress>;
  
  // Quiz operations
  submitQuizAttempt(attempt: InsertQuizAttempt): Promise<QuizAttempt>;
  getUserQuizAttempts(userId: string, quizId: number): Promise<QuizAttempt[]>;
  
  // Certificate operations
  issueCertificate(certificate: InsertCertificate): Promise<Certificate>;
  getUserCertificates(userId: string): Promise<Certificate[]>;
  getCertificate(certificateId: string): Promise<Certificate | undefined>;
  
  // Crypto payment operations
  getCryptoSettings(): Promise<CryptoSetting[]>;
  createCryptoSetting(setting: InsertCryptoSetting): Promise<CryptoSetting>;
  updateCryptoSetting(id: number, setting: Partial<InsertCryptoSetting>): Promise<CryptoSetting>;
  deleteCryptoSetting(id: number): Promise<void>;
  
  // Payment request operations
  createPaymentRequest(request: InsertPaymentRequest): Promise<PaymentRequest>;
  getPaymentRequests(status?: string): Promise<PaymentRequest[]>;
  getUserPaymentRequests(userId: string): Promise<PaymentRequest[]>;
  updatePaymentRequestStatus(id: number, status: string, adminId: string, notes?: string): Promise<PaymentRequest>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async updateUserStripeInfo(userId: string, stripeCustomerId: string, stripeSubscriptionId?: string): Promise<User> {
    const [user] = await db
      .update(users)
      .set({
        stripeCustomerId,
        stripeSubscriptionId,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  async updateUserAdminStatus(userId: string, isAdmin: boolean): Promise<User> {
    const [user] = await db
      .update(users)
      .set({
        isAdmin,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users).orderBy(desc(users.createdAt));
  }

  // Course operations
  async getAllCourses(): Promise<Course[]> {
    return await db.select().from(courses).where(eq(courses.isActive, true));
  }

  async getCourse(id: number): Promise<Course | undefined> {
    const [course] = await db.select().from(courses).where(eq(courses.id, id));
    return course;
  }

  async getCourseWithContent(id: number): Promise<any> {
    const course = await this.getCourse(id);
    if (!course) return null;

    // Get categories for this course
    const courseCategories = await db
      .select()
      .from(categories)
      .where(eq(categories.courseId, id))
      .orderBy(categories.order);

    // Get lessons for each category
    const categoriesWithContent = await Promise.all(
      courseCategories.map(async (category) => {
        const categoryLessons = await db
          .select()
          .from(lessons)
          .where(eq(lessons.categoryId, category.id))
          .orderBy(lessons.order);

        const categoryQuizzes = await db
          .select()
          .from(quizzes)
          .where(eq(quizzes.categoryId, category.id));

        return {
          ...category,
          lessons: categoryLessons,
          quizzes: categoryQuizzes,
        };
      })
    );

    // Get course-level exams (including final exam)
    const courseExams = await db
      .select()
      .from(quizzes)
      .where(eq(quizzes.courseId, id));

    return {
      ...course,
      categories: categoriesWithContent,
      exams: courseExams,
    };
  }

  async createCourse(courseData: InsertCourse): Promise<Course> {
    const [course] = await db
      .insert(courses)
      .values(courseData)
      .returning();
    return course;
  }

  async updateCourse(id: number, courseData: Partial<InsertCourse>): Promise<Course> {
    const [course] = await db
      .update(courses)
      .set(courseData)
      .where(eq(courses.id, id))
      .returning();
    return course;
  }

  async deleteCourse(id: number): Promise<void> {
    await db.delete(courses).where(eq(courses.id, id));
  }

  // Enrollment operations
  async enrollUser(enrollment: InsertEnrollment): Promise<Enrollment> {
    const [newEnrollment] = await db
      .insert(enrollments)
      .values(enrollment)
      .returning();
    return newEnrollment;
  }

  async getUserEnrollments(userId: string): Promise<Enrollment[]> {
    return await db
      .select()
      .from(enrollments)
      .where(eq(enrollments.userId, userId));
  }

  async isUserEnrolled(userId: string, courseId: number): Promise<boolean> {
    const [enrollment] = await db
      .select()
      .from(enrollments)
      .where(and(eq(enrollments.userId, userId), eq(enrollments.courseId, courseId)));
    return !!enrollment;
  }

  async getAllEnrollments(): Promise<Enrollment[]> {
    return await db.select().from(enrollments).orderBy(desc(enrollments.enrolledAt));
  }

  async adminEnrollUser(userId: string, courseId: number, adminId: string, notes?: string): Promise<Enrollment> {
    const [enrollment] = await db
      .insert(enrollments)
      .values({
        userId,
        courseId,
        paymentMethod: "admin",
        adminApprovedBy: adminId,
        adminApprovalNotes: notes,
      })
      .returning();
    return enrollment;
  }

  // Progress operations
  async getUserProgress(userId: string, courseId: number): Promise<any> {
    const courseContent = await this.getCourseWithContent(courseId);
    if (!courseContent) return null;

    const progressRecords = await db
      .select()
      .from(userProgress)
      .where(eq(userProgress.userId, userId));

    const progressMap = new Map(
      progressRecords.map((p) => [p.lessonId, p])
    );

    let totalLessons = 0;
    let completedLessons = 0;

    const categoriesWithProgress = courseContent.categories.map((category: any) => {
      const lessonsWithProgress = category.lessons.map((lesson: any) => {
        totalLessons++;
        const progress = progressMap.get(lesson.id);
        if (progress?.completed) {
          completedLessons++;
        }
        return {
          ...lesson,
          completed: progress?.completed || false,
          completedAt: progress?.completedAt,
        };
      });

      return {
        ...category,
        lessons: lessonsWithProgress,
      };
    });

    const progressPercentage = totalLessons > 0 ? Math.round((completedLessons / totalLessons) * 100) : 0;

    return {
      ...courseContent,
      categories: categoriesWithProgress,
      progress: {
        totalLessons,
        completedLessons,
        progressPercentage,
      },
    };
  }

  async updateUserProgress(progress: InsertUserProgress): Promise<UserProgress> {
    const [existingProgress] = await db
      .select()
      .from(userProgress)
      .where(and(eq(userProgress.userId, progress.userId), eq(userProgress.lessonId, progress.lessonId)));

    if (existingProgress) {
      const [updatedProgress] = await db
        .update(userProgress)
        .set({
          completed: progress.completed,
          completedAt: progress.completed ? new Date() : null,
        })
        .where(eq(userProgress.id, existingProgress.id))
        .returning();
      return updatedProgress;
    } else {
      const [newProgress] = await db
        .insert(userProgress)
        .values({
          ...progress,
          completedAt: progress.completed ? new Date() : null,
        })
        .returning();
      return newProgress;
    }
  }

  // Quiz operations
  async submitQuizAttempt(attempt: InsertQuizAttempt): Promise<QuizAttempt> {
    const [newAttempt] = await db
      .insert(quizAttempts)
      .values(attempt)
      .returning();
    return newAttempt;
  }

  async getUserQuizAttempts(userId: string, quizId: number): Promise<QuizAttempt[]> {
    return await db
      .select()
      .from(quizAttempts)
      .where(and(eq(quizAttempts.userId, userId), eq(quizAttempts.quizId, quizId)))
      .orderBy(desc(quizAttempts.attemptedAt));
  }

  // Certificate operations
  async issueCertificate(certificate: InsertCertificate): Promise<Certificate> {
    const [newCertificate] = await db
      .insert(certificates)
      .values(certificate)
      .returning();
    return newCertificate;
  }

  async getUserCertificates(userId: string): Promise<Certificate[]> {
    return await db
      .select()
      .from(certificates)
      .where(eq(certificates.userId, userId))
      .orderBy(desc(certificates.issuedAt));
  }

  async getCertificate(certificateId: string): Promise<Certificate | undefined> {
    const [certificate] = await db
      .select()
      .from(certificates)
      .where(eq(certificates.certificateId, certificateId));
    return certificate;
  }

  // Crypto payment operations
  async getCryptoSettings(): Promise<CryptoSetting[]> {
    return await db.select().from(cryptoSettings).where(eq(cryptoSettings.isActive, true));
  }

  async createCryptoSetting(setting: InsertCryptoSetting): Promise<CryptoSetting> {
    const [newSetting] = await db
      .insert(cryptoSettings)
      .values(setting)
      .returning();
    return newSetting;
  }

  async updateCryptoSetting(id: number, setting: Partial<InsertCryptoSetting>): Promise<CryptoSetting> {
    const [updatedSetting] = await db
      .update(cryptoSettings)
      .set({
        ...setting,
        updatedAt: new Date(),
      })
      .where(eq(cryptoSettings.id, id))
      .returning();
    return updatedSetting;
  }

  async deleteCryptoSetting(id: number): Promise<void> {
    await db.delete(cryptoSettings).where(eq(cryptoSettings.id, id));
  }

  // Payment request operations
  async createPaymentRequest(request: InsertPaymentRequest): Promise<PaymentRequest> {
    const [newRequest] = await db
      .insert(paymentRequests)
      .values(request)
      .returning();
    return newRequest;
  }

  async getPaymentRequests(status?: string): Promise<PaymentRequest[]> {
    const query = db.select().from(paymentRequests);
    if (status) {
      return await query.where(eq(paymentRequests.status, status)).orderBy(desc(paymentRequests.createdAt));
    }
    return await query.orderBy(desc(paymentRequests.createdAt));
  }

  async getUserPaymentRequests(userId: string): Promise<PaymentRequest[]> {
    return await db
      .select()
      .from(paymentRequests)
      .where(eq(paymentRequests.userId, userId))
      .orderBy(desc(paymentRequests.createdAt));
  }

  async updatePaymentRequestStatus(id: number, status: string, adminId: string, notes?: string): Promise<PaymentRequest> {
    const [updatedRequest] = await db
      .update(paymentRequests)
      .set({
        status,
        verifiedBy: adminId,
        verifiedAt: new Date(),
        adminNotes: notes,
      })
      .where(eq(paymentRequests.id, id))
      .returning();
    return updatedRequest;
  }
}

export const storage = new DatabaseStorage();
