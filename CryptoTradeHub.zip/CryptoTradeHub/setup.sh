#!/bin/bash

# CryptoTrade Academy - One-Click Setup Script for VPS
# This script sets up the complete application with Docker

set -e

echo "🚀 CryptoTrade Academy - VPS Setup Script"
echo "=========================================="

# Check if running as root
if [[ $EUID -eq 0 ]]; then
   echo "❌ This script should not be run as root for security reasons"
   echo "Please run as a regular user with sudo privileges"
   exit 1
fi

# Function to check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Update system packages
echo "📦 Updating system packages..."
sudo apt update && sudo apt upgrade -y

# Install Docker if not exists
if ! command_exists docker; then
    echo "🐳 Installing Docker..."
    curl -fsSL https://get.docker.com -o get-docker.sh
    sudo sh get-docker.sh
    sudo usermod -aG docker $USER
    rm get-docker.sh
    echo "✅ Docker installed successfully"
else
    echo "✅ Docker is already installed"
fi

# Install Docker Compose if not exists
if ! command_exists docker-compose; then
    echo "🐳 Installing Docker Compose..."
    sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
    sudo chmod +x /usr/local/bin/docker-compose
    echo "✅ Docker Compose installed successfully"
else
    echo "✅ Docker Compose is already installed"
fi

# Install other required packages
echo "📦 Installing additional packages..."
sudo apt install -y curl wget git ufw fail2ban

# Configure firewall
echo "🔒 Configuring firewall..."
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow ssh
sudo ufw allow 80
sudo ufw allow 443
sudo ufw allow 3000
echo "y" | sudo ufw enable

# Create application directory
APP_DIR="/opt/cryptotrade-academy"
echo "📁 Creating application directory at $APP_DIR..."
sudo mkdir -p $APP_DIR
sudo chown $USER:$USER $APP_DIR

# Clone or copy application if not in the right directory
if [ ! -f "docker-compose.yml" ]; then
    echo "📥 Application files not found in current directory"
    echo "Please ensure you're running this script from the project directory"
    echo "Or provide the project files in $APP_DIR"
    exit 1
fi

# Copy files to application directory if not already there
if [ "$(pwd)" != "$APP_DIR" ]; then
    echo "📋 Copying application files..."
    sudo cp -r * $APP_DIR/
    sudo chown -R $USER:$USER $APP_DIR
    cd $APP_DIR
fi

# Create environment file if it doesn't exist
if [ ! -f ".env" ]; then
    echo "⚙️ Creating environment configuration..."
    cat > .env << EOF
# Database Configuration
POSTGRES_PASSWORD=$(openssl rand -base64 32)

# Session Security
SESSION_SECRET=$(openssl rand -base64 64)

# Application Configuration (Update these with your values)
REPL_ID=your_repl_id_here
REPLIT_DOMAINS=your_domain.com
ISSUER_URL=https://replit.com/oidc

# Stripe Configuration (Optional - for payment processing)
STRIPE_SECRET_KEY=
VITE_STRIPE_PUBLIC_KEY=

# Production Settings
NODE_ENV=production
EOF

    echo "✅ Environment file created at .env"
    echo "❗ IMPORTANT: Please edit .env file with your actual configuration values"
fi

# Create database initialization script
echo "🗄️ Creating database initialization script..."
cat > init.sql << 'EOF'
-- Create sessions table for express-session
CREATE TABLE IF NOT EXISTS sessions (
  sid varchar NOT NULL COLLATE "default",
  sess json NOT NULL,
  expire timestamp(6) NOT NULL
)
WITH (OIDS=FALSE);

ALTER TABLE sessions ADD CONSTRAINT session_pkey PRIMARY KEY (sid) NOT DEFERRABLE INITIALLY IMMEDIATE;
CREATE INDEX IF NOT EXISTS IDX_session_expire ON sessions (expire);

-- Grant necessary permissions
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO postgres;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO postgres;
EOF

# Create SSL certificate directory
echo "🔒 Setting up SSL certificates directory..."
mkdir -p ssl

# Create nginx configuration for production
echo "🌐 Creating nginx configuration..."
cat > nginx.conf << 'EOF'
server {
    listen 80;
    server_name _;
    
    # Redirect HTTP to HTTPS
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl;
    server_name _;
    
    # SSL Configuration
    ssl_certificate /etc/ssl/certs/cert.pem;
    ssl_certificate_key /etc/ssl/private/key.pem;
    
    # Security headers
    add_header X-Frame-Options DENY;
    add_header X-Content-Type-Options nosniff;
    add_header X-XSS-Protection "1; mode=block";
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains";
    
    # Proxy to application
    location / {
        proxy_pass http://app:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_read_timeout 90;
    }
    
    # Static file caching
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg)$ {
        proxy_pass http://app:5000;
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}
EOF

# Create backup script
echo "💾 Creating backup script..."
cat > backup.sh << 'EOF'
#!/bin/bash

# Create backup directory
BACKUP_DIR="/opt/cryptotrade-academy/backups"
mkdir -p $BACKUP_DIR

# Create database backup
docker-compose exec -T db pg_dump -U postgres cryptotrade_academy > "$BACKUP_DIR/db_backup_$(date +%Y%m%d_%H%M%S).sql"

# Create application backup
tar -czf "$BACKUP_DIR/app_backup_$(date +%Y%m%d_%H%M%S).tar.gz" --exclude=backups --exclude=node_modules .

# Keep only last 7 days of backups
find $BACKUP_DIR -name "*.sql" -mtime +7 -delete
find $BACKUP_DIR -name "*.tar.gz" -mtime +7 -delete

echo "Backup completed successfully"
EOF

chmod +x backup.sh

# Create systemd service for automatic startup
echo "🔄 Creating systemd service..."
sudo cat > /etc/systemd/system/cryptotrade-academy.service << EOF
[Unit]
Description=CryptoTrade Academy Application
Requires=docker.service
After=docker.service

[Service]
Type=oneshot
RemainAfterExit=yes
WorkingDirectory=$APP_DIR
ExecStart=/usr/local/bin/docker-compose up -d
ExecStop=/usr/local/bin/docker-compose down
TimeoutStartSec=0

[Install]
WantedBy=multi-user.target
EOF

# Enable the service
sudo systemctl daemon-reload
sudo systemctl enable cryptotrade-academy.service

# Build and start the application
echo "🚀 Building and starting the application..."
docker-compose build --no-cache
docker-compose up -d

# Initialize database with sample data if needed
echo "📊 Setting up initial data..."
sleep 20  # Wait for database to be ready

# Run database initialization
docker-compose exec -T app node -e "
const { pool } = require('./dist/db.js');

async function initializeData() {
  try {
    // Check if courses exist
    const result = await pool.query('SELECT COUNT(*) FROM courses');
    const courseCount = parseInt(result.rows[0].count);
    
    if (courseCount === 0) {
      console.log('Initializing course data...');
      
      // Insert courses
      await pool.query(\`
        INSERT INTO courses (name, description, level, price) VALUES 
        ('Cryptocurrency Basics & Blockchain Fundamentals', 'Master the fundamentals of blockchain technology, Bitcoin, Ethereum, and cryptocurrency markets. Learn wallet security, basic trading concepts, and market analysis. Perfect for absolute beginners with no prior crypto experience.', 'basic', '0.00'),
        ('Technical Analysis & Trading Psychology', 'Advanced trading strategies including technical analysis, chart patterns, candlestick analysis, market indicators, risk management, and trading psychology. Learn to read market sentiment and execute profitable trades consistently.', 'intermediate', '50.00'),
        ('DeFi Protocols & Advanced Trading Strategies', 'Master decentralized finance, yield farming, liquidity mining, derivatives trading, algorithmic trading strategies, and portfolio management. Learn to navigate complex DeFi protocols and maximize returns through advanced techniques.', 'advanced', '100.00')
      \`);
      
      // Insert crypto settings
      await pool.query(\`
        INSERT INTO crypto_settings (currency, wallet_address, network_name, is_active) VALUES 
        ('BTC', '1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa', 'Bitcoin Mainnet', true),
        ('ETH', '0x742d35Cc6861C4532231E5e7B57C37B1839C4565', 'Ethereum Mainnet', true),
        ('USDT', '0x742d35Cc6861C4532231E5e7B57C37B1839C4565', 'Ethereum (ERC-20)', true)
        ON CONFLICT DO NOTHING
      \`);
      
      console.log('Sample data initialized successfully');
    } else {
      console.log('Course data already exists, skipping initialization');
    }
  } catch (error) {
    console.error('Error initializing data:', error);
  } finally {
    await pool.end();
  }
}

initializeData();
" 2>/dev/null || echo "Database initialization will be handled by the application"

# Wait for services to be ready
echo "⏳ Waiting for services to start..."
sleep 30

# Check if services are running
if docker-compose ps | grep -q "Up"; then
    echo "✅ Services are running successfully!"
else
    echo "❌ Some services failed to start. Checking logs..."
    docker-compose logs
    exit 1
fi

# Create admin user setup script
cat > create-admin.sh << 'EOF'
#!/bin/bash
echo "Creating admin user..."
docker-compose exec -T db psql -U postgres -d cryptotrade_academy -c "UPDATE users SET is_admin = true WHERE email = '$1';"
echo "Admin user created for email: $1"
EOF

chmod +x create-admin.sh

# Setup log rotation
echo "📝 Setting up log rotation..."
sudo cat > /etc/logrotate.d/cryptotrade-academy << 'EOF'
/opt/cryptotrade-academy/logs/*.log {
    daily
    missingok
    rotate 52
    compress
    delaycompress
    notifempty
    create 644 root root
}
EOF

# Create monitoring script
cat > monitor.sh << 'EOF'
#!/bin/bash

# Check if containers are running
if ! docker-compose ps | grep -q "Up"; then
    echo "⚠️ Some containers are down. Restarting..."
    docker-compose restart
fi

# Check disk space
DISK_USAGE=$(df / | tail -1 | awk '{print $5}' | sed 's/%//')
if [ $DISK_USAGE -gt 80 ]; then
    echo "⚠️ Disk usage is ${DISK_USAGE}%. Consider cleaning up."
fi

# Check memory usage
MEMORY_USAGE=$(free | grep Mem | awk '{printf "%.1f", $3/$2 * 100.0}')
if (( $(echo "$MEMORY_USAGE > 90" | bc -l) )); then
    echo "⚠️ Memory usage is ${MEMORY_USAGE}%"
fi

echo "✅ System monitoring completed"
EOF

chmod +x monitor.sh

# Add monitoring to crontab
(crontab -l 2>/dev/null; echo "*/5 * * * * $APP_DIR/monitor.sh >> $APP_DIR/logs/monitor.log 2>&1") | crontab -
(crontab -l 2>/dev/null; echo "0 2 * * * $APP_DIR/backup.sh >> $APP_DIR/logs/backup.log 2>&1") | crontab -

# Create logs directory
mkdir -p logs

echo ""
echo "🎉 Setup completed successfully!"
echo "=========================================="
echo ""
echo "📍 Application URL: http://$(curl -s ifconfig.me):3000"
echo "📁 Application directory: $APP_DIR"
echo "📝 Environment file: $APP_DIR/.env"
echo ""
echo "🔧 Next Steps:"
echo "1. Edit the .env file with your configuration:"
echo "   nano $APP_DIR/.env"
echo ""
echo "2. Update these important values:"
echo "   - REPL_ID: Your Replit application ID"
echo "   - REPLIT_DOMAINS: Your domain name"
echo "   - STRIPE_SECRET_KEY: Your Stripe secret key (if using payments)"
echo "   - VITE_STRIPE_PUBLIC_KEY: Your Stripe public key (if using payments)"
echo ""
echo "3. Restart the application after updating configuration:"
echo "   cd $APP_DIR && docker-compose restart"
echo ""
echo "4. Create an admin user (after first login):"
echo "   cd $APP_DIR && ./create-admin.sh your-email@example.com"
echo ""
echo "5. Set up SSL certificate for production (recommended):"
echo "   - Place your SSL certificate as ssl/cert.pem"
echo "   - Place your private key as ssl/key.pem"
echo "   - Uncomment SSL configuration in docker-compose.yml"
echo ""
echo "🔍 Useful commands:"
echo "   - View logs: cd $APP_DIR && docker-compose logs -f"
echo "   - Restart: cd $APP_DIR && docker-compose restart"
echo "   - Stop: cd $APP_DIR && docker-compose down"
echo "   - Update: cd $APP_DIR && git pull && docker-compose build && docker-compose up -d"
echo "   - Backup: cd $APP_DIR && ./backup.sh"
echo ""
echo "📊 The application includes:"
echo "   ✅ Automatic backups (daily at 2 AM)"
echo "   ✅ System monitoring (every 5 minutes)"
echo "   ✅ Log rotation"
echo "   ✅ Firewall configuration"
echo "   ✅ Auto-restart on boot"
echo ""
echo "🔐 Security recommendations:"
echo "   - Change default passwords in .env"
echo "   - Set up SSL certificates"
echo "   - Keep the system updated"
echo "   - Monitor logs regularly"
echo ""
echo "Need help? Check the documentation or logs for troubleshooting."
EOF

chmod +x setup.sh